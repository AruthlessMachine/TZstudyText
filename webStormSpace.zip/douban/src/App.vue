<template>
  <div id="app">
    <home-title :title = 'title' v-if="show"></home-title>
    <router-view/>
  </div>
</template>

<script>
  import HomeTitle from '@/components/HomeTitle'

  export default {
    data(){
      return {
        title: '豆瓣电影Top250',
        show:true
      }
    },
    components:{
      HomeTitle
    },
    // async created(){
    //   let {data:{count,subjects,title,total}} = await this.$axios.get('/api/v2/movie/top250?count=20&&start=20')
    //   this.title = title
    // }
  }
</script>

<style>
  *{
    margin: 0;
    padding: 0;
  }
  body{
    background: #222;
  }
</style>
