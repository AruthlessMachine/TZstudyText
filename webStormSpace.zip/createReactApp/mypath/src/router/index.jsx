import  Home from '../components/home'
import  List from '../components/list'
import  Search from '../components/search'
import  Content from '../components/content'

const routes =[
    {
        path:'/',
        component:Home,
        children:[
            {
                path:'/list',
                component:List
            },
            {
                path:'/search',
                component:Search
            },
            {
                path:'/content',
                component:Content
            }
        ]

    }

]



export default routes;






