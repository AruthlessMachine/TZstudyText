import React from 'react';
import {
    BrowserRouter,
    Route
} from 'react-router-dom';

import routes from './router'
import './index.css'

function App() {
  return (
      <BrowserRouter>
          <div className="App">

              {
                  routes.map((item,index)=>{
                      if(item.children){
                          return <Route
                            key={index}
                            path={item.path}
                            render= {( props )=> {
                                return <item.component routes={ item.children } />
                            }} />
                      } else {
                          return <Route key={index} { ...item } />
                      }
                  })
              }
          </div>
      </BrowserRouter>

  );
}

export default App;
