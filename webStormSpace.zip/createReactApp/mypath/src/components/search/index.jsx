import React, {Component} from 'react';

class Search extends Component {
    render() {
        return (
            <div>
                Search
            </div>
        );
    }
}

export default Search;