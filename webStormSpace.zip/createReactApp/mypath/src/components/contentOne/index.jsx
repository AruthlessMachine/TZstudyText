import React, {Component} from 'react';
// import './index.css'

class Content extends Component {
    constructor(props){
        super(props)
        this.state = {

        }
    }

    render() {
        return (
            <div>
                
                content----1
            </div>
        );
    }
}

export default Content;