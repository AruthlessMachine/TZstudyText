import React, {Component} from 'react';

class List extends Component {
    render() {
        return (
            <div>
                List
            </div>
        );
    }
}

export default List;