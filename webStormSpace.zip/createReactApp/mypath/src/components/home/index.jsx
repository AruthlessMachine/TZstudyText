import React, {Component} from 'react';
import {
    Route,
    NavLink
} from 'react-router-dom';

import './index.css'

class Home extends Component {
    constructor(props){
        super(props)
        this.state = {
            routes:[]
        }




    }

    componentWillMount(){
        let {routes} = this.props
        this.setState({
            routes
        })
    }

    render() {
        return (
            <div className={'home'}>
                <ul>
                    <li><NavLink to={'/search'}>search</NavLink></li>
                    <li><NavLink to={'/list'}>list</NavLink></li>
                    <li><NavLink to={'/content'}>content</NavLink></li>
                </ul>

                {
                    this.state.routes.map((item,index)=>{
                        if(item.children){
                            return <Route
                                key={index}
                                path={item.path}
                                render= {( props )=> {
                                    return <item.component routes={ item.children } />
                                }} />
                        } else {
                            return <Route key={index} { ...item } />
                        }
                    })
                }
            </div>
        );
    }
}

export default Home;