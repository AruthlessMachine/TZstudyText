import React from 'react';
import './App.css';

import Home from './views/home'
function App() {

    return (
        <div className="App">
            <Home></Home>
        </div>
    )
}


export default App;

