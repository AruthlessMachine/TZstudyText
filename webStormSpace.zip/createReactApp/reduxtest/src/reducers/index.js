
// 将所有redux文件合并
import { combineReducers } from 'redux'

import reduxOne from './redux1.js'
import reduxTwo from './redux2.js'

let Reducers = combineReducers({
    reduxOne,
    reduxTwo
})

export default Reducers;