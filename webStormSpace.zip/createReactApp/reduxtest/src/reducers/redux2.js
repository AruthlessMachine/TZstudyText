
export default function( state={}, action ) {
    let goods = action
    switch (action.type) {
        case 'ADD_DATA' :
            return {
                state
            };
        case 'RM_DATA' :
            return {
                state
            };
        case 'CLEAR_DATA' :
            return {
                state
            };
        default :
            return state
    }
}