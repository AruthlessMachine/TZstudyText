
export default function( state=0, action ) {
    let goods = action.data
    switch (action.type) {
        case 'ADD_DATA' :
            return  state+goods.num
            ;
        case 'RM_DATA' :
            return  state-goods.num
            ;
        case 'CLEAR_DATA' :
            return 0;
        default :
            return state
    }
}