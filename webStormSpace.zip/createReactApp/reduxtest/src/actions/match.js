
export function addNum(data) {
    return {
        type:'ADD_DATA',
        data
    }
}

export function rmNum(data) {
    return {
        type:'RM_DATA',
        data
    }
}

export function clearNum() {
    return {
        type:'CLEAR_DATA'
    }
}

export function asyncAddNum(data) {
    return dispath=>(
        setTimeout(()=>{
            dispath(addNum(data))
        },1000)
    )
}

export function asyncRmNum(data) {
    return dispath=>(
        setTimeout(()=>{
            dispath(rmNum(data))
        },1000)
    )
}