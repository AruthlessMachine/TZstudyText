import React, {Component} from 'react';
import {connect} from 'react-redux'
import {addNum,rmNum,clearNum,asyncAddNum,asyncRmNum} from '../actions/match.js'

class Home extends Component {




    handleClick(){
        let { addNum } = this.props
        addNum({num:1})
    }

    render() {
        let { rmNum,clearNum,asyncAddNum,asyncRmNum,reduxOne } = this.props
        return (
            <div>
                <h1>{reduxOne}</h1>
                <hr/>
                <button
                    onClick={ this.handleClick.bind(this) }
                >按钮++</button>
                <button
                    onClick={ ()=>{
                        rmNum({num:1})
                    }}
                >按钮--</button>
                <button
                    onClick={ ()=>{
                        clearNum()
                    }}
                >clear</button>
                <button
                    onClick={ ()=>{
                        asyncAddNum({num:20})
                    }}
                >按钮async++</button>
                <button
                    onClick={ ()=>{
                        asyncRmNum({num:.5})
                    }}
                >按钮async--</button>

            </div>
        );
    }
}

Home = connect(state=>state,{
    addNum,
    rmNum,
    clearNum,
    asyncAddNum,
    asyncRmNum
})(Home)

export default Home;