const mongoose = require('mongoose')

const projectSchema = new mongoose.Schema({
    title:String,
    describe:String,
    color:String,
    imageSrc:String,
    linkSrc:String,
})

module.exports = mongoose.model('projects',projectSchema)