const mongoose = require('mongoose')

const friendLinkSchema = new mongoose.Schema({
    title:String,
    linkSrc:String
})

module.exports = mongoose.model('friendLinks',friendLinkSchema)