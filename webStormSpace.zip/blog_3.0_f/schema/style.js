const mongoose = require('mongoose')

const styleSchema = new mongoose.Schema({
    title:String,
    imageSrc:String
})

module.exports = mongoose.model('styles',styleSchema)