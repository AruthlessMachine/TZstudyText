module.exports = {
    style : require('./style'),
    category : require('./category'),
    content : require('./content'),
    poster : require('./poster'),
    swiper : require('./swiper'),
    authorSay : require('./authorSay'),
    shortcut : require('./shortcut'),
    project : require('./project'),
    friendLink : require('./friendLink'),
    users : require('./users')
}