const mongoose = require('mongoose')

const shortcutSchema = new mongoose.Schema({
    title:String,
    imageSrc:String,
    linkSrc:String,
})

module.exports = mongoose.model('shortcuts',shortcutSchema)