const mongoose = require('mongoose')

const swiperSchema = new mongoose.Schema({
    title:String,
    imageSrc:String,
    linkSrc:String
})

module.exports = mongoose.model('swipers',swiperSchema)