const mongoose = require('mongoose')

const contentSchema = new mongoose.Schema({
    category:Array,
    linkSrc:String,
    imageSrc:String,
    title:String,
    author:String,
    views:{
        type:Number,
        default: 0
    },
    admire:{
        type:Number,
        default: 0
    },
    time:{
        type:Date,
        default:new Date()
    },
    describe:String,
    content:Array,
    comment:{
        type:Array,
        default:[]
    },
})

module.exports = mongoose.model('contents',contentSchema)