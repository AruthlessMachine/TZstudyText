const mongoose = require('mongoose')

const posterSchema = new mongoose.Schema({
    title:String,
    imageSrc:String,
    linkSrc:String
})

module.exports = mongoose.model('posters',posterSchema)