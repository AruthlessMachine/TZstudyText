const mongoose = require('mongoose')

const authorSaySchema = new mongoose.Schema({
    title:String,
    imageSrc:String,
    describe:String,
    content:String,
})

module.exports = mongoose.model('authorSays',authorSaySchema)