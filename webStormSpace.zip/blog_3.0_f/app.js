const express = require('express')
const mongoose = require('mongoose')
const bodyParser = require('body-parser')

const app = express()


app.use(bodyParser.urlencoded({extended:true}))
app.use(bodyParser.json())
app.use(express.static('public'))


app.use((req,res,next)=>{
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Headers', 'Content-type');
    res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS,PATCH");
    next()
})



app.use('/',require('./routers/main'))

app.use('/admin',require('./routers/admin'))

app.use('/api',require('./routers/api'))

mongoose.connect('mongodb://localhost:27017/blog',{useNewUrlParser:true},(err)=>{
    if(err){
        console.log('err')
        return
    } else {
        console.log('数据库已连接')
    }
    app.listen(80)
})



