const express = require('express')
const User = require('../schema/users')

const router = express.Router()


router.post('/login',(req,res)=>{
    let {username,user,password} = req.body

    User.findOne({user}).then((result)=>{
        if(username !== ''){
            if(result){
                return res.send({err:1})
            } else {
                new User({
                    username,
                    user,
                    password
                }).save().then((err)=>{
                    if(err){
                        return res.send({
                            err:0,
                            date:{username,user,password}
                        })
                    }
                })
            }
        } else {
            if(!result) return res.send({err:1})
            if(result.password === password){
                res.send({err:0,date:result})
            } else {
                res.send({err:1})
            }
        }
    })
})

module.exports = router