const express = require('express')
const mgSchema = require('../schema/entryFile.js')

const router = express.Router()

router.post('/',(req,res)=>{
    let data = {
        style:null,
        friendLink:null
    }

    datas()
    async function datas(){
        for(let key in data){
            data[key] =  await mgSchema[key].find()
        }
        res.send(data)
    }
})

router.post('/home',(req,res)=>{
    let data = {
        category:null,
        shortcut:null,
        authorSay:null,
        project:null,
        poster:null,
        swiper:null
    }

    datas()
    async function datas(){
        for(let key in data){
            data[key] =  await mgSchema[key].find()
        }
        mgSchema.content.find().then((value)=>{
            data.length = value.length

            let arr = []
            for (let i in value) {
                arr.push({
                    id:value[i]._id,
                    title:value[i].title,
                    imageSrc:value[i].imageSrc,
                    views:value[i].views,
                    time:value[i].time,
                    describe:value[i].describe,
                    category:value[i].category
                })
            }
            data.content = arr.slice(0,8)
            arr.sort((a,b)=> b.views - a.views)
            data.likeContent = arr.slice(0,5)
            data.poster = data.poster[new Date().getDate()%data.poster.length]
            res.send(data)
        })
    }
})

router.post('/list',(req,res)=>{
    let {cate} = req.body

    let data = {
        length:0,
        queryStr:[],
        content:[],
        poster:[]
    }

    mgSchema.content.find().then((value)=>{
        if (cate){
           value = value.filter(v=>{
               return v.category.indexOf(cate) !== -1
           })
        }

        data.length = value.length
        for (let i in value) {
            data.queryStr.push({
                id:value[i]._id,
                title:value[i].title
            })

            if(i < 8){
                data.content.push({
                    id:value[i]._id,
                    title:value[i].title,
                    imageSrc:value[i].imageSrc,
                    views:value[i].views,
                    admire:value[i].admire,
                    time:value[i].time,
                    describe:value[i].describe
                })
            }
        }
        mgSchema.poster.find().then((rut)=>{
            data.poster = rut[new Date().getDate()%rut.length]
            res.send(data)
        })
    })


})

router.post('/article',(req,res)=>{
    let {id} = req.body
    let data = {
        content:{},
        contentList:[],
    }
    mgSchema.content.findOne({_id:id}).then((reslut)=>{
        if(!reslut) return res.send()
        reslut.views++
        data.content = reslut
        mgSchema.content.find().then((rut)=>{
            for (let i of rut) {
                data.contentList.push({
                    id:i._id,
                    title:i.title
                })
            }
            res.send(data)
            reslut.save()
        })

    })
})

router.post('/project',(req,res)=>{
    let {num} = req.body
    let data = {
        content:[]
    }
    mgSchema.content.find().limit(8).skip(8*num).then((value)=>{
        for (let i in value) {
            data.content.push({
                id:value[i]._id,
                title:value[i].title,
                imageSrc:value[i].imageSrc,
                views:value[i].views,
                admire:value[i].admire,
                time:value[i].time,
                describe:value[i].describe
            })
        }
        res.send(data)
    })



})

router.post('/article/admire',(req,res)=>{
    let {id} = req.body
    mgSchema.content.findOne({_id:id}).then((data)=>{
        data.admire++
        data.save()
    })
    res.send()
})

router.post('/article/comment',(req,res)=>{
    let {id,com} = req.body
    mgSchema.content.findOne({_id:id}).then((data)=>{
        data.comment.unshift(com)
        data.save()
        res.send({err:0})

    })
})



module.exports = router