const express = require('express')

const mgSchema = require('../schema/entryFile.js')
const User = require('../schema/users')

const router = express.Router()

router.use((req,res,next)=>{
    let {user} = req.body
    if(!user){
        return res.send('sss')
    }
    User.findOne({user}).then((results)=>{
        if(results){
            if(results.isAdmin){
                next()
            } else {
                res.send()
            }
        }
    })
})

router.post('/add',(req,res)=>{
    let {type,data} = req.body

    for(let key in data){
        if(!data[key]){
            res.send({err:1})
            return
        }
    }
    if(mgSchema[type]){
        new mgSchema[type](data).save().then((err)=>{
            if (err) {
                res.send({err:0})
                return
            }
        })
    }
    res.send({err:1})
})

router.post('/datalist',(req,res)=>{
    let {type} = req.body

    if(mgSchema[type]){
        mgSchema[type].find().then((result)=>{

            let arr = []
            for(let rut of result){
                arr.push({
                    id : rut._id,
                    title : rut.title
                })
            }
            res.send(arr)
        })

        return
    }
    res.send({err:1})
})

router.post('/remove',(req,res)=>{
    let {type,id} = req.body
    if(mgSchema[type]){
        mgSchema[type].deleteOne({_id:id}).then((err)=>{
            res.send({err:0})
        })
        return
    }
    res.send({err:1})
})


router.post('/update',(req,res)=>{
    let {id,type} = req.body
    mgSchema[type].findOne({_id:id}).then((result)=>{
        res.send(result)
    })
})

router.post('/setupdate',(req,res)=>{
    let {id,type,date} = req.body
    mgSchema[type].updateOne({_id:id},{$set:date})
    .then((result)=>{
        if(result){
            res.send({err:0})
        } else {
            res.send({err:1})
        }
    })
})

// router.post('/upload')

module.exports = router