<template>
    <div class="main-body">
      <div class="main-body-con"  v-if="content">
        <div class="main-t">
          <h3>{{content.title}}</h3>
          <div class="main-adm">
            <p>
              <span>作者：冷酷无情的机器</span>
              <span>观看：{{content.views}}</span>
              <span>点赞：{{content.admire}}</span>
              <span>分类：<span v-for="i in content.category">{{i}}</span></span>
              <span>发布时间：{{content.time}}</span>
            </p>
          </div>
          <div class="main-img" v-if='content.imageSrc'>
            <img :src="content.imageSrc" alt="">
          </div>
          <div class="main-related" v-if="content['linkSrc']">
            <a :href="content.linkSrc" target='_blank'>查看项目</a>
          </div>
        </div>
        <ul class="main-con">
          <li v-for="item in content.content" ref="conList" v-if="item.code">
            <h4>{{item.title}}</h4>
            <p>{{item.text}}</p>
            <div class="main-con-img" v-if="item['image']">
              <img v-if='item.image' :src="item.image" alt="">
            </div>
            <div class="main-code-con">
              <ol v-if="item.code.length" class="main-code" >
                <li v-for="(v,i) in item.code">
                  <i>{{i}}</i>
                  <pre v-html="v">{</pre>
                </li>
              </ol>
            </div>
          </li>

        </ul>
        <div class="admire">
          <span class="iconfont icon-dianzan" :class="{'admire-mark':AdmireColor}"  @click.stop="changeAdmire"></span>
        </div>
        <div class="page-turner">
          <span class='top-con' v-if="topCon"  @click="changeContent(1)">上一篇：{{topCon.title}}</span>
          <span class='bottom-con' v-if="bottomCon" @click="changeContent(0)">下一篇：{{bottomCon.title}}</span>
        </div>
      </div>

      <div class="main-body-nav" v-if="isWidth">
        <div>
          <div>
            <h4><span class="iconfont icon-Shapecopy"></span><span>{{content.title}}</span></h4>
            <ul>
              <li v-for="(item,index) in content.content"
                  @click="scrollNav(index)"
                  :class="{'nav-bg':index === num}"
              >{{item.title}}</li>
            </ul>
          </div>
        </div>
      </div>

      <div class="open-com" @click.stop="changeSwitch">
        <span class="iconfont icon-linedesign-01"></span>
        <i v-if="content.comment">{{content.comment.length}}</i>
      </div>
    </div>
</template>

<script>
  import {setAdmire} from '@/api'

  export default {
    name:'mainBody',
    props:['content','contentList'],
    data() {
      return {
        AdmireColor:false,
        comSwitch:false,
        page:0,
        topCon:{},
        bottomCon:{},
        scroll:null,
        num:-1,
        isWidth:window.innerWidth > 700
      }
    },
    created(){
      setTimeout(()=>{
        this.scroll = this.$store.state.goScrool
      })
    },
    methods:{
      changeSwitch(){
        this.comSwitch = !this.comSwitch
        if(this.comSwitch){
          if(this.isWidth){
            this.$store.commit('changeSwitch',460)
          } else {
            this.$store.commit('changeSwitch',window.innerWidth)
          }
        } else {
          this.$store.commit('changeSwitch',0)
        }
      },

      changeAdmire(){
        this.AdmireColor = !this.AdmireColor
        if (this.AdmireColor) {
          setAdmire({id:this.$route.query.id})
        }
      },

      changeContent(bool){
        if(bool){
          this.$router.push({
            path:'/article',
            query:{id:this.topCon.id}
          })
        } else {
          this.$router.push({
            path:'/article',
            query:{id:this.bottomCon.id}
          })
        }
        this.$router.go(0)
      },

      scrollNav(index){
        if(!this.scroll) return
        this.scroll.anima({
          top:-this.$refs.conList[index].offsetTop-20
        },200)
      },

      scrollMath(s){
        this.num = this.$refs.conList.findIndex(v=> {
          return -s < v.offsetTop+30
        })
      }
    },

    watch:{
      contentList(){
        this.contentList.filter((v,i)=>{
          if(v.id == this.$route.query.id){
            this.page = i
            return true
          }
        })
        this.topCon = this.contentList[this.page-1]
        this.bottomCon = this.contentList[this.page+1]
      },
      'scroll.s'(s){
        if(!this.$refs.conList) return
        this.scrollMath(s)
      }
    }
  }

</script>

<style scoped>
  .nav-bg{
    background-color: #eee;
  }
  .page-turner{
    height: 40px;
    margin: 30px 0 0;
  }
  .page-turner span{
    overflow: hidden;
    float: left;
    width: 253px;
    height: 38px;
    margin: 0 60px;
    line-height: 38px;
    text-indent: 10px;
    border: 1px dashed #6e6aff;
    color: #6e6aff;
    cursor: pointer;
  }
  .page-turner .bottom-con{
    float: right;
  }
  .page-turner span:hover{
    background-color: #6e6aff;
    color: #fff;
  }
  .open-com{
    position: fixed;
    z-index: 998;
    right: 50px;
    bottom: 20px;
    width: 60px;
    height: 60px;
    background-color: #333;
    line-height: 60px;
    text-align: center;
    border-radius: 100%;
    cursor: pointer;
    transition: .4s;
    box-shadow: 0 0 5px 0 rgba(0,0,0,.5) ;
  }
  .open-com span{
    font-size: 36px;
    color: #fff5ab;
  }
  .open-com i {
    position: absolute;
    width: 16px;
    height: 16px;
    right: 6px;
    top: 6px;
    font-style: normal;
    color: #fff;
    line-height: 16px;
    background-color: #ff605a;
    font-size: 12px;
    border-radius: 100%;

  }
  .open-com:hover{
    background-color: #ccc;
    transform: translateY(-3px);
  }

  .main-body{
    max-width: 1100px;
    margin: 30px auto 0;
    text-align: left;
  }

  .main-body-con{
    position: relative;
    max-width: 750px;
    padding: 50px 30px;
    background-color: #fff;
    box-shadow: 0 0 15px 0 rgba(0,0,0,.5);
  }
  .main-body-con::before{
    content: '博客正文';
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 50px;
    line-height: 50px;
    text-align: center;
    color: #fff;
    font-size: 20px;
    background-image: linear-gradient(to right,rgb(204, 85, 149), rgb(204, 85, 120),rgb(204, 85, 149));

  }
  .main-t{
    border-bottom: 2px solid #ddd;
  }
  .main-t h3{
    height: 50px;
    line-height: 50px;
    font-size: 36px;
    text-indent: 20px;
  }

  .main-t p{
    padding-left: 25px;
  }
  .main-t p span{
    display: inline-block;
    margin-right: 10px;
  }
  .main-img{
    padding: 20px 0;
  }

  .main-img img{
    width: 100%;
  }
  .main-related{
    position: absolute;
    right: 30px;
    top: 56px;
    width: 100px;
    background-color: #ffaef3;
    color: #fff;
    border-radius: 5px;
  }
  .main-related a{
    display: block;
    height: 40px;
    line-height: 40px;
    text-align: center;
  }
  .main-related:hover{
    background-color: #ff5eac;
  }
  .main-con{
    padding: 20px 0;
    border-bottom: 2px solid #ddd;

  }

  .main-con h4{
    height: 30px;
    font-size: 20px;
    line-height: 30px;
    text-indent: 15px;
    background-color: #eee;
  }

  .main-con p{
    padding: 15px;
    line-height: 24px;
    font-size: 16px;
    text-indent: 30px;
  }
  .main-con-img{
    padding: 20px 0;
  }
  .main-con-img img{
    width: 100%;
  }
  .admire{
    padding: 40px 0;
    border-bottom: 2px solid #ddd;
  }
  .admire span{
    display: block;
    width: 100px;
    height: 60px;
    margin: auto;
    border-radius: 60px;
    text-align: center;
    line-height: 60px;
    font-size: 30px;
    cursor: pointer;
    box-shadow: 0 0 10px 0 rgba(0,0,0,.2);
    color: #ccc;
  }
  .admire .admire-mark{
    color: #43be87;
  }
  .main-body-nav{
    position: fixed;
    z-index: 9;
    top: 80px;
    left: calc(50% + 260px);
    width: 290px;
  }
  .main-body-nav > div{
    padding: 0 30px;
  }

  .main-body-nav > div > div{
    overflow: hidden;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 0 10px 0 rgba(0,0,0,.4);
  }
  .main-body-nav > div h4{
    overflow: hidden;
    height: 30px;
    padding: 5px 15px;
    background-image: linear-gradient(to right,rgb(204, 85, 149), rgb(204, 85, 120),rgb(204, 85, 149));
    font-size: 14px;
    font-weight: normal;
    line-height: 30px;
    color: #eee;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .main-body-nav h4 span {
    margin-right: 10px;
  }
  .main-body-nav > div ul{
    padding: 10px 0;
  }
  
  .main-body-nav ul li {
    overflow: hidden;
    position: relative;
    height: 30px;
    margin: 5px 0;
    padding: 0 30px;
    line-height: 30px;
    white-space: nowrap;
    text-overflow: ellipsis;
    cursor: pointer;
  }

  .main-body-nav ul li:hover{
    background: #eee;
  }

  .main-con ol{
    width: 700px;
    padding: 20px 20px 20px 30px;
    background-color: #2b2b2b;
    color: #dedede;
    user-select: text;
  }

  .main-code-con{
    overflow: auto;
    margin: 15px 0;
    border-radius: 6px;
  }
  .main-code > li {
    position: relative;
    height: 18px;
    padding-left: 15px;
    line-height: 18px;
    border-left: 2px solid #ff499c;

  }
  .main-code i{
    position: absolute;
    left: -30px;
    width: 30px;
    text-align: center;
    font-style: normal;
    font-size: 12px;
    color: #ff1de7;
    user-select: none;
  }

</style>

<style>
  span.txt-mark {
    color: #ff804a!important;
  }

  span.txt-yellow {
    color: #ffed63;
  }

  span.txt-pur {
    color: #f061ff;
  }

  span.txt-green {
    color: #468f4f;
  }

  span.txt-blue {
    color: #28e3eb;
  }

  span.txt-gray,.txt-gray span{
    color: #616161!important;
  }
</style>
