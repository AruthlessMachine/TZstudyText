<template>
    <div class="comment" :style="{'width':$store.state.comSwitch+'px'}" >
      <div>
        <div ref="commentCon" class="comment-con">
          <ul ref="scrollTop">
            <li v-for="item in commentList">
              <div class="spokesman">
                <h5 v-if="$store.state.userList" :class="{'user-color':item.name === $store.state.userList.username}">{{item.name}}</h5>
                <div>{{item.time}}</div>
              </div>
              <div class="comments">
                <p>
                  <pre>{{item.con}}</pre>
                </p>
              </div>
            </li>
          </ul>
        </div>

        <div class="comment-push">
          <div class="comment-btn">
            <span @click="changeSwitchText">{{SwitchTextCon}}</span>
          </div>
          <div class="comment-text" :class="{'com-mark':SwitchText}">
            <h5>留言板</h5>
            <div class="comment-t-c">
              <textarea placeholder="请在这里留下评论（<=200）" resize="none"  v-model="comText"></textarea>
            </div>
            <div class="comment-b-c">
              <span @click="comment">发送</span>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
  import Scroll from '@/assets/js/scroll.js'

  import {addComment} from '@/api'
  export default {
    name:'comment',
    props:['comments'],
    data() {
      return {
        SwitchText : false,
        SwitchTextCon:'发表评论',
        comText:'',
        commentList:[],
        time:new Date()
      }
    },
    mounted(){
      setTimeout(()=>{
        if(this.$store.state.isMove){
          this.setScrool()
        } else {
          this.$refs['commentCon'].style.overflowY = 'scroll'
        }
      })
    },
    watch:{
      comments(){
        this.commentList = this.comments
      }
    },

    methods:{
      setScrool(){
        new Scroll(this.$refs['scrollTop'],80)
      },

      changeSwitchText(){
        this.SwitchText = !this.SwitchText
        if(this.SwitchText){
          this.SwitchTextCon = '收起'
        }else{
          this.SwitchTextCon = '发表评论'
        }
      },
      comment(){
        if(new Date() - this.time < 2000) return
        this.time = new Date()
        if(!this.$store.state.userList){
          this.$store.commit('changeloginShow',true)
          return
        }
        if(this.comText.trim() === '' || this.comText.length > 200) return
        let data = {
          name:this.$store.state.userList.username,
          time:new Date().toLocaleString(),
          con:this.comText
        }
        addComment({
          id:this.$route.query.id,
          com:data
        }).then((res)=>{
          if(!res.err){
            this.comText = ''
            this.commentList.unshift(data)
          }
        })
      }
    }
  }
</script>

<style scoped>
  .comment{
    position: fixed;
    z-index: 997;
    width: 0;
    height: 100%;
    top: 0;
    right: 0;
    background: #fff;
    text-align: left;
    transition: .3s;
  }

  .comment > div{
    position: relative;
    height: calc(100% - 40px);
    padding: 20px;
  }
  .comment-con{
    overflow: hidden;
    position: absolute;
    left: 20px;
    top: 20px;
    right: 20px;
    bottom: 20px;
  }
  .comment ul{
    position: absolute;
    padding-bottom: 250px;
    left: 0;
    top: 0;
    width: 100%;
  }
  .comment ul::after{
    content: '已经见底了';
    display: block;
    height: 20px;
    line-height: 20px;
    text-align: center;
    margin-top: 10px;
  }
  .comment ul li{
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
  }

  .comment .spokesman{
    position: relative;
    height: 20px;
    padding: 5px 0 5px 10px;
    line-height: 20px;
  }
  .comment .spokesman h5{
    font-size: 18px;
    font-weight: normal;
    color: #000;
  }
  .comment .spokesman > div{
    position: absolute;
    top: 5px;
    right: 15px;
    height: 20px;
    font-size: 12px;
  }
  .comments{
    padding: 10px 15px;
    background: #ffefef;
  }

  .comments p{
    text-indent: 24px;
    font-size: 12px;
    line-height: 20px;
    letter-spacing: 2px;
    color: #999;
    user-select: text;
  }

  .comment-push{
    position: absolute;
    bottom: 0;
    width: calc(100% - 40px);
  }

  .comment-push .comment-btn{
    padding-bottom: 15px;
  }
  .comment-btn span{
    display: block;
    width: 200px;
    height: 30px;
    margin: auto;
    border-radius: 8px;
    background: cornflowerblue;
    line-height: 30px;
    font-size: 14px;
    color: #fff;
    text-align: center;
    cursor: pointer;
    box-shadow: 0 0 10px 0 rgba(0,0,0,.5),
    inset -3px -3px 5px 5px rgb(100,120,230);
    transition:  .3s;
  }
  .comment-btn span:hover{
    transform: translateY(-5px);
  }
  .comment-push .comment-text{
    height: 0;
    background: #e8fdff;
  }

  .comment-text h5{
    background: #ffde83;
    line-height: 30px;
    font-size: 14px;
    font-weight: normal;
    text-indent: 15px;
  }
  .comment-t-c{
    padding: 10px 15px;

  }
  .comment-text textarea{
    overflow: hidden;
    display: block;
    width: 88%;
    height: 80px;
    padding: 5px 20px;
    resize: none;
    outline: none;
    border-radius: 5px;
    font-size: 12px;
    color: #999;
    line-height: 20px;
  }
  .comment-b-c{
    padding-bottom: 10px;
  }
  .comment-b-c span{
    display: block;
    width: 150px;
    height: 40px;
    margin: auto;
    border-radius: 4px;
    background: #1be2ed;
    line-height: 40px;
    font-size: 14px;
    color: #fff;
    text-align: center;
    cursor: pointer;
  }
  .com-mark{
    height: auto!important;
  }
  .user-color{
    color: #ffc81e !important;
  }

</style>

