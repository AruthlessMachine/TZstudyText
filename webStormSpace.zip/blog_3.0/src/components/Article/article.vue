<template>
    <div class="article">
      <main-body :content="content" :contentList="contentList"></main-body>
      <comment :comments="content.comment"></comment>
    </div>
</template>

<script>
    import {getArticleData} from '@/api'

    import Comment from '@/components/Article/base/comment'
    import MainBody from '@/components/Article/base/mainBody'

    export default {
      name:'articleCon',
      data() {
          return {
            content : {},
            contentList:[]
          }
      },
      components:{
        MainBody,
        Comment,
      },
      created(){
        this.$store.commit('changelodShow',true)
        this.getData()
      },

      methods:{
        async getData(){
          let {content,contentList} = await getArticleData({id:this.$route.query.id})
          this.content = content
          this.contentList = contentList

          setTimeout(()=>{
            this.$store.commit('changelodShow',false)
          })
        }
      }
    }
</script>

<style scoped>

</style>
