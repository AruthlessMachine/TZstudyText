<template>
  <div class="home">
    <header-nav :category="category"></header-nav>
    <picture-file :poster="poster" :swiper="swiper"></picture-file>

    <like-list :content="likeContent">
      <like-header slot="header" :authorSay="authorSay[0]"></like-header>
      <fast-entrance slot="fast" :shortcut="shortcut"></fast-entrance>
    </like-list>

    <project :content="content">
      <like-header :authorSay="authorSay[1]"></like-header>
      <project-list :content="content" :length="length"></project-list>
    </project>

    <author-items :project='project'></author-items>
  </div>
</template>

<script>
  import {getHomeData} from '@/api'

  import HeaderNav from '@/components/home/base/headerNav'
  import PictureFile from '@/components/home/base/pictureFile'
  import LikeList from '@/components/home/base/likeList'
  import Project from '@/components/home/base/project'
  import AuthorItems from '@/components/home/base/authorItems'

  import LikeHeader from '@/common/likeHeader'
  import FastEntrance from  '@/common/fastEntrance'
  import ProjectList from '@/common/projectList'

  export default {
    name:'home',
    data() {
      return {
        category:[],
        shortcut:[],
        authorSay:[],
        project:[],
        content:[],
        likeContent:[],
        poster:[],
        swiper:[],
        length:0
      }
    },
    components:{
      PictureFile,
      LikeList,
      Project,
      AuthorItems,
      HeaderNav,
      LikeHeader,
      FastEntrance,
      ProjectList
    },
    created(){
      this.$store.commit('changelodShow',true)
      this.getData()
    },
    mounted(){
      this.isShow = false
    },
    methods:{
      async getData(){
        let {
          category,
          shortcut,
          authorSay,
          project,
          content,
          likeContent,
          poster,
          swiper,
          length
        } = await getHomeData()
        this.category = category
        this.shortcut = shortcut
        this.authorSay = authorSay
        this.project = project
        this.content = content
        this.likeContent = likeContent
        this.poster = poster
        this.swiper = swiper
        this.length = length
        setTimeout(()=>{
          this.$store.commit('changelodShow',false)
        })
      }
    }
  }
</script>

<style scoped>

</style>
