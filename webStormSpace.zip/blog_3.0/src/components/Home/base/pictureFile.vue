<template>
  <div ref="pic" class='picture-file'>
    <div class='picture-con'  v-if="poster">
      <div class='scale' :style="{'background-image':`url(${poster.imageSrc})`}"></div>
      <h3 class='img-title'>
        <a :href="poster.linkSrc">{{poster.title}}</a>
      </h3>
    </div>
    <div class='rotation'>
      <div class='rotation-con' @mouseenter="clearTimer" @mouseleave="setTimer">
        <h3>我推荐的</h3>
        <div class='btn'>
          <span class='btn-left iconfont icon-jiantou_zuo' @click="changeSwiper(0)"></span>
          <span class='btn-right iconfont icon-jiantou' @click="changeSwiper(1)"></span>
        </div>
        <div class='rotation-module clearfix'>
          <ul :style="{left:posNum+'px',width:swiper.length*360+'px'}">
            <li v-for="item in swiper">
              <a :href="item.linkSrc">
                <div class="rotation-title">{{item.title}}</div>
                <div class="rotation-img" v-lazy:background-image="item.imageSrc"></div>
                <!--:style="{'background-image':`url(${item.imageSrc})`}"-->
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name:'picture-file',
    props:['poster','swiper'],
    data() {
        return {
          arr2:[1,2,3,4,5,6,7,8,9,10],
          posNum:0,
          timer:null,
          time:0,
          num:3
        }
    },
    mounted(){
      this.$refs['pic'].style.height = (innerHeight + 350) + 'px'
      this.setTimer()
      if(window.innerWidth < 800 && window.innerWidth > 400) this.num = 2
      if(window.innerWidth < 400) this.num = 1
    },
    methods:{
      changeSwiper(num){
        if(new Date() - this.time < 1000) return
        this.time = new Date()
        if(num) {
          if(this.posNum-(360*this.num)<=-this.swiper.length*360){
            this.posNum = 0
            return
          }
          this.posNum -= 360*this.num
        } else {
          console.log(this.posNum+(360*this.num))

          if(this.posNum+(360*this.num)>0){
            this.posNum = (Math.ceil(this.swiper.length/this.num)-1)*(-360*this.num)
            return
          }

          this.posNum+=360*this.num
        }
      },
      setTimer(){
        this.timer = setInterval(()=>{
          this.changeSwiper(1)
        },5000)
      },
      clearTimer(){
        clearInterval(this.timer)
      }
    }
  }
</script>

<style scoped>

  .picture-file .picture-con {
    position: relative;
    overflow: hidden;
    height: calc(100% - 350px);
  }

  .picture-con > div{
    height:100%;
    background-position: center;
    background-size: cover;
    transition: transform 16s;
  }

  .picture-con:hover .scale{
    transform: scale(1.1);
  }

  .picture-con .img-title{
    position: absolute;
    top: 40%;
    width: 100%;
    font-size: 40px;
    line-height: 70px;
    color:#eee;

  }

  .picture-con .img-title a{
    display: inline-block;
    font-weight: normal;
    transition: color 1s;
  }
  .picture-con .img-title a:hover{
    color: #ffff00;
  }
  .rotation{
    margin-top: -100px;
  }

  .rotation .rotation-con{
    position: relative;
    max-width: 1080px;
    margin: auto;
  }
  .rotation .rotation-con h3{
    height: 50px;
    margin: 0;
    padding: 0 50px;
    border-bottom: 1px solid #eee;
    line-height: 50px;
    text-align: left;
    font-size: 26px;
    font-weight: normal;
    color: #eee;
  }

  .rotation-con .btn{
    position: absolute;
    top: 10px;
    right: 20px;
    width: 99px;
    height: 30px;
    border: 1px solid #fff;
    line-height: 30px;
    border-radius: 5px;

  }
  .rotation-con .btn span{
    float: left;
    width: 49px;
    font-size: 34px;
    color: #eee;
    cursor: pointer;
    transition: background-color .5s,color .5s;
  }
  .rotation-con .btn span:hover{
    background-color: #fff;
    color: #333;
  }
  .rotation-con .btn-left{
    border-right: 1px solid #fff;
  }

  .rotation-module{
    overflow: hidden;
    position: relative;
    margin-top: 10px;
    height: 360px;
  }
  .rotation-module ul{
    position: absolute;
    top: 0;
    transition:  left 1s;
  }
  .rotation-module li {
    overflow: hidden;
    float: left;
    position: relative;
    width: 300px;
    margin: 0 30px;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0,0,0,.5);
  }

  .rotation-img{
    height: 360px;
    background-position: center;
    background-size: cover;
    transition: .5s;
  }

  .rotation-module li:hover .rotation-img{
    transform: scale(1.2);
    opacity: .8;
  }
  .rotation-module li:hover .rotation-title {
    height: 100%;
    opacity: .2;
  }
  .rotation-title{
    position: absolute;
    z-index: 1;
    top: 50%;
    left: 0;
    width: 300px;
    height: 40px;
    background-color: rgba(0,0,0,.6);
    line-height: 40px;
    color: #eee;
    transform: translateY(-50%);
    transition:  .5s;
  }
</style>
