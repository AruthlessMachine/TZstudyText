<template>
  <div class='author-items' >
    <div class='author-list'>
      <ul class="clearfix" :class="{'author-items-mark':listHeight}">
        <li v-for="item in project">
          <a :href="item.linkSrc" target="_blank">
            <div>
              <img :src="item.imageSrc">
            </div>
            <div class='author-text' :style="{'background-color':item.color}">
              <h5>{{item.title}}</h5>
              <p>
                  <span>
                      {{item.describe}}
                  </span>
              </p>
            </div>
          </a>
        </li>

      </ul>
      <div class='on-offf iconfont icon-Shapecopy' @click="openList"></div>
    </div>
  </div>
</template>

<script>
  export default {
    name:'authorItems',
    props:['project'],
    data() {
      return {
        listHeight:false,
      }
    },
    methods:{
      openList(){
        this.listHeight = !this.listHeight
      }
    }
  }
</script>

<style scoped>
  .author-items{
    position: relative;
    margin-top: 100px;
    background-color: rgba(0,0,0,.8);
  }

  .author-list{
    max-width: 1100px;
    margin: auto;
    padding: 50px 0;
  }
  .author-list ul{
    overflow: hidden;
    height: 180px;
  }
  .author-items-mark{
    height: auto!important;
  }
  .author-list li{
    position: relative;
    overflow: hidden;
    float: left;
    width: 140px;
    height: 140px;
    margin: 20px;
    border-radius: 15px;
  }
  .author-list li:nth-of-type(6n){
    margin-right: 0;
  }
  .author-list li a{
    display: block;
  }
  .author-list li img{
    width: 100%;
  }
  .author-list li .author-text{
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 0;
    transition: height .5s;
    opacity: .8;
  }
  .author-text h5{
    height: 30px;
    padding: 10px 20px 0;
    line-height: 30px;
    color: #333;
    font-size: 14px;
  }
  .author-text p{
    overflow: hidden;
    position: relative;
    height: 60px;
    font-size: 12px;
    line-height: 20px;
  }

  .author-text p span{
    position: absolute;
    left: 10px;
    top: 0;
    width: 120px;
    transition: bottom 1s;
  }

  .author-list li:hover .author-text{
    height: 100%;
  }

  .on-offf{
    position: absolute;
    top: 10px;
    left: 50%;
    width: 120px;
    height: 30px;
    margin-left: -60px;
    border: 1px solid #666;
    border-radius: 5px;
    line-height: 30px;
    cursor: pointer;
    transition: border-color .5s,color .5s;
  }
  .on-offf:hover{
    border-color: #eee;
    color: #fff;
  }
</style>
