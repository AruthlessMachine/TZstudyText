<template>
  <div class='project'>
    <slot></slot>
  </div>
</template>

<script>

  export default {
    name:'project',
    data() {
        return {}
    }
  }

</script>

<style scoped>
</style>
