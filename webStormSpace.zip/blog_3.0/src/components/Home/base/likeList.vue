<template>
  <div class='like'>
   <slot name="header"></slot>
    <div class='like-body'>
      <div class="like-body-con clearfix" :class="{'like-show':!$store.state.isMove}">
        <div class='like-list'>
          <div>
            <ul class='like-list-con'>
              <li v-for="item in content">
                <div class='scale' v-lazy:background-image="item.imageSrc"></div>
                <router-link :to="{path:'/article',query:{id:item.id}}" tag="a">
                  <h4>
                    <span>{{item.title}}</span>
                  </h4>
                  <div class='like-paragraph'>
                    <p>{{item.describe}}</p>
                  </div>
                  <div class='like-time'>{{item.time.toLocaleString()}}</div>
                  <div class='like-lable'>
                    <router-link v-for="(i,index) in item.category" :to="{path:'/list',query:{cate:i}}" tag="span" :key="index">{{i}}</router-link>
                  </div>
                </router-link>
              </li>
            </ul>
          </div>
        </div>
        <div class='heat-list'>
          <slot name="fast"></slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

  export default {
    name:'likeList',
    props:['content'],
    data() {
      return {
      }
    }
  }
</script>

<style scoped>

  .like-body-con{
    max-width: 1100px;
    margin: auto;
  }
  .like-body-con > div{
    float: left;
  }

  .like-body-con .like-list{
    width: 750px;
  }
  .like-show > div{
    float: none;
    width: 100% !important;
    margin: auto;
  }
  .heat-list{
    width: 350px;
  }

  .like-list > div{
    width: 100%;
    padding: 20px 30px;
    box-sizing: border-box;
  }

  .like-list-con > li{
    overflow: hidden;
    position: relative;
    height: 150px;
    margin: 10px 0;
    border: 1px solid #aaa;
    color: #eee;
    background-color: rgba(0,0,0,.6);
    border-radius: 5px;
    box-shadow: 0 0 5px 0 rgba(0,0,0,.6),
    0 0 0 7px inset rgba(0,0,0,.5),
    0 0 0 7px inset #eee;
    transition: .8s;
  }
  .like-list-con > li:hover{
    border-color: #eee;
    box-shadow: 0 5px 10px 3px rgba(0,0,0,.7),
    0 0 0 7px inset rgba(0,0,0,.5),
    0 0 0 8px inset #eee;
    color: #fff;
  }

  .like-list-con > li:hover .scale{
    transform: scale(1.1);
  }

  .like-list-con .scale{
    height: 100%;
    background-size: cover;
    background-position: center;
    opacity: .7;
    transition: transform .3s;
  }

  .like-list-con a {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
  }

  .like-list-con a h4{
    padding: 5px 100px;
    line-height: 40px;
    padding: 10px 100px;
    font-size: 22px;
  }

  .like-list-con h4 span{
    overflow: hidden;
    display: block;
    height: 40px;
  }

  .like-paragraph{
    padding: 0 50px 5px;
  }
  .like-list-con p {
    overflow: hidden;
    height: 40px;
    line-height: 20px;
  }

  .like-time{
    position: absolute;
    right: 10px;
    bottom: 8px;
  }

  .like-lable{
    position: absolute;
    left: 15px;
    bottom: 10px;
  }
  .like-lable span{
    display: inline-block;
    margin: 0 5px;
    padding: 3px 5px;
    border: 1px solid #eee;
    border-radius: 5px;
  }
  .like-lable span:hover{
    background-color: #fff;
    color: #999;
  }
</style>
