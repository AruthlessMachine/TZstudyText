<template>
  <div class='header-con'>
    <div>
      <h1 id='logo'><a href="">A ruthless machine</a></h1>
      <nav>
        <ul>
          <li v-for="item in category"><router-link :to="{path:'/list',query:{cate:item.title}}" tag="a" :key="item.id">{{item.title}}</router-link></li>
        </ul>
      </nav>
    </div>
  </div>
</template>

<script>
    export default {
        name:'headerNav',
        props:['category'],
        data() {
            return {}
        }
    }
</script>

<style scoped>
  .header-con{
    position: absolute;
    width: 100%;
    left: 0;
    top: 50px;
    z-index: 3;
  }


  .header-con>div{
    background-image: linear-gradient(to bottom,rgba(0,0,0,.6),transparent);
    background-color: rgba(0,0,0,0);
    transition: 2s;
  }
  .header-con>div:hover{
    background-color: rgba(0,0,0,.5);
  }
  #logo{
    padding-top: 20px;
    font-size: 50px;
    color: #eee;
  }
  .header-con nav{
    position: relative;
    padding: 20px 50px 20px 20px;
    font-size: 18px;
    color: #fff;
  }
  .header-con nav ul{
    width: 80%;
  }
  .header-con nav li {
    display: inline-block;
    transition: color .3s;
  }

  .header-con nav li:hover{
    color: rgb(221, 79, 146);
  }

  .header-con nav a{
    display: block;
    padding: 5px 15px;

  }
  .header-con nav .down-menu{
    position: absolute;
    left: 50%;
    margin-left: -40%;
    width: 80%;
    height: 300px;
    background-color: #fff8;
  }

</style>
