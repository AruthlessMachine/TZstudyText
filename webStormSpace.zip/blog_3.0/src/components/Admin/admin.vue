<template>
    <div class="admin clearfix">
      <div class="menu">
        <ul>
          <router-link :to="{path:'/admin/datalist',query:{type:'style'}}" tag="li">风格列表</router-link>
          <router-link :to="{path:'/admin/datalist',query:{type:'category'}}" tag="li">分类列表</router-link>
          <router-link :to="{path:'/admin/datalist',query:{type:'content'}}" tag="li">内容列表</router-link>
          <router-link :to="{path:'/admin/datalist',query:{type:'poster'}}" tag="li">海报列表</router-link>
          <router-link :to="{path:'/admin/datalist',query:{type:'swiper'}}" tag="li">轮播列表</router-link>
          <router-link :to="{path:'/admin/datalist',query:{type:'authorSay'}}" tag="li">作者言</router-link>
          <router-link :to="{path:'/admin/datalist',query:{type:'shortcut'}}" tag="li">快捷文档</router-link>
          <router-link :to="{path:'/admin/datalist',query:{type:'project'}}" tag="li">项目列表</router-link>
          <router-link :to="{path:'/admin/datalist',query:{type:'friendLink'}}" tag="li">友情链接</router-link>
        </ul>
        <ul>
          <router-link :to="{path:'/admin/add',query:{type:'style'}}" tag="li">风格添加</router-link>
          <router-link :to="{path:'/admin/add',query:{type:'category'}}" tag="li">分类添加</router-link>
          <router-link :to="{path:'/admin/add',query:{type:'content'}}" tag="li">内容添加</router-link>
          <router-link :to="{path:'/admin/add',query:{type:'poster'}}" tag="li">海报添加</router-link>
          <router-link :to="{path:'/admin/add',query:{type:'swiper'}}" tag="li">轮播添加</router-link>
          <router-link :to="{path:'/admin/add',query:{type:'authorSay'}}" tag="li">作者言添加</router-link>
          <router-link :to="{path:'/admin/add',query:{type:'shortcut'}}" tag="li">快捷文档添加</router-link>
          <router-link :to="{path:'/admin/add',query:{type:'project'}}" tag="li">项目添加</router-link>
          <router-link :to="{path:'/admin/add',query:{type:'friendLink'}}" tag="li">友情链接添加</router-link>
        </ul>
        <ul>
          <router-link to="/admin/upload" tag="li">图片上传</router-link>
        </ul>
      </div>
      <div class="component clearfix">
        <div ref="scroll">
          <router-view></router-view>
        </div>
      </div>
    </div>
</template>

<script>
  import Scroll from '@/assets/js/scroll.js'

  export default {
    name:'admin',
    data() {
        return {
          scroll:null
        }
    },

    created(){
      if(!this.$store.state.userList)return this.$router.push({path:'/'})
      if(!this.$store.state.userList.isAdmin)return this.$router.push({path:'/'})

      this.$store.commit('changelodShow',false)
      setTimeout(()=>{
        this.scroll = new Scroll(this.$refs['scroll'])
      })
    },

    methods:{
      goToTop(){
        this.scroll.anima({
          top:0,
        },100)
      },
    },
    updated(){
      this.goToTop()
    },

  }
</script>

<style scoped>
  .admin > div{
    float: left;
  }
  .menu{
    width: 20%;
    height: 100%;
    background-color: #2a2928;
    color: #eee;
  }
  .menu ul{
    padding: 20px 0;
  }

  .menu ul li{
    height: 30px;
    line-height: 30px;
    cursor: pointer;
  }
  .menu ul li:hover{
    background-color: #fff;
    color: #999;
  }
  .component{
    position: relative;
    width: 80%;
  }
  .component > div{
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    padding-bottom: 100px;
  }
  .router-link-exact-active{
    background: #00d2d8;
  }


</style>
