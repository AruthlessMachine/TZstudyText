<template>
    <div class="data-list">
      <div>
        <textarea ref='updateCon' v-html="content"></textarea>
      </div>
      <div class="btn-sbmit">
        <span @click="setUpdate">提交修改</span>
      </div>
    </div>
</template>

<script>
  import {setDataList,setUpdate} from '@/api'

  export default {
    name: 'update',
    data() {
      return {
        content:{},
      }
    },
    created(){
      this.getDate()
    },

    methods:{
      async getDate(){
        this.content = await setDataList({
          id:this.$route.query.id,
          type:this.$route.query.type,
          user:this.$store.state.userList.user
        })
        delete this.content._id
        delete this.content.__v
        delete this.content.comment
        delete this.content.time
      },

      setUpdate(){
        try{
          let date = JSON.parse(this.$refs.updateCon.value)
          setUpdate({
            id:this.$route.query.id,
            type:this.$route.query.type,
            user:this.$store.state.userList.user,
            date
          }).then((res)=>{
            console.log()
            if(res.err){
              alert('修改失败了')
            } else {
              alert('修改成功了')
            }
          })
        } catch (e) {
          return alert('格式错误无法序列化！')
        }
      }
    }
  }
</script>

<style scoped>
  .data-list{
    padding: 50px 20px;
  }

  .data-list textarea{
    width:80%;
    min-height: 400px;
    padding: 20px;
    line-height: 20px;
    outline: none;
  }
  .btn-sbmit{
    padding: 20px 0;
  }
  .btn-sbmit span{
    display: block;
    width: 120px;
    height: 50px;
    margin: auto;
    background-color: #fff;
    font-size: 20px;
    line-height: 50px;
    border-radius: 5px;
    box-shadow: 0 0 10px 0 rgba(0,0,0,.5);
    cursor: pointer;
  }
  .btn-sbmit span:hover{
    background-color: #77cc6d;
    color: #fff;
  }
</style>
