<template>
    <div class="add">
      <div class="add-text">
        <h3 v-if="isShow">
          <input type="text" v-model="num">
          <button @click="upload">上传</button>
          <button @click="last">返回</button>
        </h3>
        <div>
            <textarea v-model="template" name=""></textarea>
        </div>
      </div>
      <div class="btn-sbmit">
        <span @click="changeText">{{changeBtn}}</span>
      </div>
    </div>
</template>

<script>
  import {addData} from '@/api/index.js'

  export default {
    name: 'add',
      data() {
        return {
          isShow :false,
          changeBtn:'提交添加',
          num:0,
          value:'',
          data:{
            "title":"",
            "linkSrc":"",
            "imageSrc":"",
            "describe":"",
            "color":"",
            "category":[],
            "content":[
              {
                "title":"",
                "text":"",
                "image":"",
                "code":[]
              }
            ]
          },
          template:`  {
    "title":"",
    "linkSrc":"",
    "imageSrc":"",
    "describe":"",
    "color":"",
    "category":["js"],
    "content":[
       {
         "title":"",
         "text":"",
         "image":"",
         "code":[]
       }
    ]
  }
`,

          text:`{
    "title":"",
    "linkSrc":"",
    "imageSrc":"",
    "describe":"",
    "color":"",
    "category":["js"],
    "content":[
       {
         "title":"",
         "text":"",
         "image":"",
         "code":[]
       }
    ]
  }
  `,
        }
      },

      methods:{
        last(){
          this.isShow = false
          this.template = this.text
          this.changeBtn='提交添加'
        },
        addData(){
          addData({
            type:this.$route.query.type,
            data:this.data,
            user:this.$store.state.userList.user
          }).then((result)=>{
            if(result.err !== 0){
              console.log(result)
              alert('上传失败')
            } else {
              this.isShow = false
              this.template = this.text
              this.changeBtn='提交添加'
              alert('上传成功')
            }
          })
        },
        upload(){
          if(this.$route.query.type !== this.value){
            this.$router.push({
              path:this.$router.path,
              query:{type:this.value}
            })
          }
          setTimeout(()=>{
            this.addData()
          })
        },
        changeText(){
          if (!this.isShow){
            try{
              let data = JSON.parse(this.template)
              if (data instanceof Object){
                this.data = data
                if(!this.data.content){
                  return this.addData()
                } else {
                  this.value = this.$route.query.type
                  this.template = 'push code'
                  this.isShow = !this.isShow
                  this.changeBtn = 'push'
                }
              }
            } catch(err) {
              return alert(err)
            }

          } else {
            if(!this.data.content[this.num]) return alert('num 不存在')
            this.changePush()
          }
        },
        changePush(){
          let regList = {
            textColor:['txt-green','txt-blue','txt-mark','txt-yellow','txt-pur','txt-gray','none'],
            textReg : [
              /(".*?"|'.*?')/g,
              /[\s?]\d*\.?\d+\b/g,
              /\s{1}(let|const|break|case|catch|continue|default|delete|do|else|finally|for|function|if|in|instanceof|new|return|switch|this|throw|try|typeof|var|void|while|with|abstract|boolean|byte|char|class|debugger|double|enum|export|extends|final|float|goto|implements|import|int|interface|long|native|package|private|protected|public|short|static|super|synchronized|throws|transient|volatile)\s+?/g,
              /\w+\(/g,
              /\.\w+/g,
              /(\/\/.*?\n|(\/\*(.|\n|\r)*\*\/))/g,
              /.*?\n/g,
            ]
          }

          this.template = this.template.replace(/</g,'&lt;')

          this.template = this.template.replace(/>/g,'&gt;')

          for(let i in regList.textColor){
            this.template = this.reg(regList.textReg[i],regList.textColor[i])
          }
        },

        reg(reg1,classN) {
          let arr = []
          setTimeout(()=>{
            if(arr.toString()) {
              this.data.content[this.num].code = arr
              this.num++
              this.template = 'push完成'
            }
          },300)


          return this.template.replace(reg1,(value)=>{
            if(classN == 'txt-yellow'){
              return `<span class="${classN}">${value.slice(0,value.length-1)}</span>(`
            } else if (classN == 'txt-pur'){
              return `.<span class="${classN}">${value.slice(1,value.length)}</span>`
            } else if(classN == 'none'){
              arr.push(value)
              return arr
            } else {
              return `<span class="${classN}">${value}</span>`
            }
          })
        }
      }
    }
</script>

<style scoped>
  .btn-sbmit{
    padding: 20px 0;
  }

  .add-text{
    padding: 30px 60px;
  }

  .add-text h3{
    height: 30px;
    padding: 20px 0 0;
    text-align: left;
    text-indent: 20px;
    line-height: 30px;
    font-size: 22px;
    font-weight: normal;
    color: #eee;
  }
  .add-text h3 button {
    width: 60px;
    cursor: pointer;
  }
  .add-text > div{
    padding: 5px 20px;
  }

  .add-text textarea{
    display: block;
    width: 95%;
    height: 400px;
    padding: 15px;
    font-size: 16px;
    line-height: 18px;
    border-radius: 5px;
  }

  .btn-sbmit span{
    display: block;
    width: 120px;
    height: 50px;
    margin: auto;
    background-color: #fff;
    font-size: 20px;
    line-height: 50px;
    border-radius: 5px;
    box-shadow: 0 0 10px 0 rgba(0,0,0,.5);
    cursor: pointer;
  }
  .btn-sbmit span:hover{
    background-color: #77cc6d;
    color: #fff;
  }

</style>
