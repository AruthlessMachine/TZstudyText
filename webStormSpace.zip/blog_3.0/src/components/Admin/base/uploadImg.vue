<template>
    <div class="upload">


      <div class="btn-sbmit">
        <span>提交上传</span>
      </div>
    </div>
</template>

<script>
  export default {
    name: 'upload',
    data() {
      return {}
    }
  }
</script>

<style scoped>
  .btn-sbmit{
    padding: 20px 0;
  }
  .btn-sbmit span{
    display: block;
    width: 120px;
    height: 50px;
    margin: auto;
    background-color: #fff;
    font-size: 20px;
    line-height: 50px;
    border-radius: 5px;
    box-shadow: 0 0 10px 0 rgba(0,0,0,.5);
    cursor: pointer;
  }
  .btn-sbmit span:hover{
    background-color: #77cc6d;
    color: #fff;
  }
</style>
