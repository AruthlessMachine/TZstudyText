<template>
    <div class="data-list">
      <div>
        <ul>
          <li v-for="(item,index) in dataArr">
            <h3>{{item.title}}</h3>
            <div class="btn">
              <span class="btn-update" @click="updateCon(item.id)">修改</span>
              <span class="btn-remove" @click="removeCon(item.id,index)">删除</span>
            </div>
          </li>
        </ul>
      </div>
    </div>
</template>

<script>

  import {getDataList,removeDataList} from '@/api'

  export default {
    name: 'dataList',
    data() {
      return {
        dataArr:[]
      }
    },
    created(){
      this.getDataList()
    },
    watch:{
      '$route' : 'getDataList'
    },
    methods:{
      getDataList(){
        getDataList({type:this.$route.query.type,user:this.$store.state.userList.user}).then((res)=>{
          if(res.err == 1){
            return alert('访问出错了')
          }
          this.dataArr = res
        })
      },

      removeCon(id,index){
        removeDataList({
          type : this.$route.query.type,
          id,
          user:this.$store.state.userList.user
        }).then((res)=>{
          if(res.err){
            alert('删除失败了')
          } else {
            this.dataArr.splice(index,1)
            alert('删除成功')
          }
        })
      },

      updateCon(id){
        this.$router.push({
          path:'/admin/update',
          query:{type:this.$route.query.type,id}
        })
      }
    }
  }
</script>

<style scoped>
  .data-list > div{
    padding: 80px 50px 150px;
  }

  .data-list ul{
    border-top: 1px solid #999;
    border-left: 1px solid #999;
    color: #fff;
    font-size: 16px;
    background-color: rgba(0,0,0,.5);
  }

  .data-list li{
    position: relative;
    height: 36px;
    border-right: 1px solid #999;
    border-bottom: 1px solid #999;
    line-height: 36px;
    text-align: left;
  }
  .data-list li:hover{
    background-color: #00d2d8;
  }
  .data-list li h3{
    font-weight: normal;
    text-indent: 15px;
  }
  .btn{
    position: absolute;
    right: 0;
    top: 0;
    height: 40px;
    padding: 0 20px;
    cursor: pointer;
  }
  .btn span:hover{
    color: #f6000a;
  }

</style>
