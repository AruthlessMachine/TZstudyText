<template>
    <div class="search">
      <div class="img-search" :class="{'img-search-focus':imgFilter}" :style="{'background-image':`url(${poster.imageSrc})`}"></div>
      <div class="search-con">
        <div class="box-search">
          <input type="text" placeholder="输入你想知道的" @focus="textFocus" @blur="textBlur" @input="searchList" @keydown.enter="searchEnter" v-model="keyword">
          <button class="iconfont icon-sousuo6" @click="searchEnter"></button>
        </div>
        <ul v-if="newArr.length">
          <router-link :to="{path:'/article',query:{id:item.id}}" tag="li" v-for="(item,index) in newArr" :key="index">{{item.title}}</router-link>
        </ul>
      </div>
    </div>
</template>

<script>
  export default {
    name:'search',
    props:['queryStr','poster'],
    data() {
      return {
        imgFilter:false,
        newArr:[],
        keyword:'',
        timer:null
      }
    },
    watch:{
      poster(){

      }
    },
    methods:{
      textFocus(){
        if(this.poster){
          this.imgFilter = true
        }
        this.searchList()
      },
      textBlur(){
        this.imgFilter = false
        setTimeout(()=>{
          this.newArr = []
        },200)
      },
      searchList(){
          clearTimeout(this.timer)
          this.timer = setTimeout(() => {
            this.newArr = this.queryStr.filter(v=>{
              if (this.keyword.trim()=='') return false
              let str1 = v.title.toLocaleLowerCase()
              let str2 = this.keyword.trim().toLocaleLowerCase()

              return str1.includes(str2)
            })
          }, 100);
      },
      searchEnter(){
        if (!this.newArr.length) return
        this.$router.push({
          path:'/article',
          query:{id:this.newArr[0].id}
        })
      }
    }
  }
</script>

<style scoped>
  .search{
    position: relative;
    height: 240px;
  }

  .search > .search-con{
    position: relative;
    left: 50%;
    max-width: 700px;
    transform: translateX(-50%);
  }
  .search ul {
    position: absolute;
    width: 80%;
    z-index: 3;
    left: 50%;
    top: -95px;
    transform: translateX(-50%);
    padding: 20px 0;
    background-color: #fff;
    box-shadow: 0 0 5px rgba(0,0,0,.5);
  }
  .search ul li{
    height: 36px;
    margin: 5px 0;
    padding: 0 30px;
    text-align: left;
    line-height: 36px;
    cursor: pointer;
  }
  .search ul li:first-child{
    background-color: #ff68b2;
  }
  .search ul li:hover{
    background-color: #eee;
  }

  .search .img-search{
    height: 240px;
    background-size: cover;
    background-position: center;
  }
  .search .img-search-focus{
    filter: blur(4px);
  }

  .box-search{
    position: absolute;
    top: -120px;
    left: 50%;
    z-index: 3;
    width: 80%;
    height: 48px;
    background-color: #fff;
    text-align: left;
    transform: translate(-50%,-50%);
  }
  .box-search input{
    float: left;
    width: calc(100% - 50px);
    height: 46px;
    outline: none;
    border: 1px solid #eee;
    vertical-align: middle;
    font-size: 15px;
    color: #333;
    text-indent: 15px;
  }

  .box-search button{
    float: left;
    width: 48px;
    height: 48px;
    border: 0;
    background-color: transparent;
    outline: none;
    font-size: 20px;
    font-weight: bold;
    color: #aaa;
    vertical-align: middle;
    cursor: pointer;
  }
  .box-search button:hover{
    color: #000;
  }
</style>
