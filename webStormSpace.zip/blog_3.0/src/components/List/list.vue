<template>
  <div class="home">
    <search :queryStr="queryStr" :poster="poster"></search>
    <div class="order">
      <ul>
        <li @click.stop="slotCon('id')" :class="{'btn-bg':btnBg === 'id'}">按时间</li>
        <li @click.stop="slotCon('admire')" :class="{'btn-bg':btnBg === 'admire'}">按热度</li>
        <li @click.stop="slotCon('views')" :class="{'btn-bg':btnBg === 'views'}">按阅读量</li>
      </ul>
      <project-list :content="content" :length="length"></project-list>
    </div>
  </div>
</template>

<script>
  import {getListData} from '@/api'

  import Search from '@/components/list/base/search'

  import ProjectList from '@/common/projectList'

  export default {
    name:'list',
    data() {
      return {
        length:0,
        content:[],
        queryStr:[],
        poster:{},
        btnBg:'id'
      }
    },
    components:{
      Search,
      ProjectList
    },
    created(){
      this.$store.commit('changelodShow',true)
      this.getData()
    },
    mounted() {
        this.isShow = false
    },
    methods:{
      async getData(){
        let {length,content,queryStr,poster} = await getListData({cate:this.$route.query.cate})
        this.length = length
        this.content = content
        this.queryStr = queryStr
        this.poster = poster
        setTimeout(()=>{
          this.$store.commit('changelodShow',false)
        })
      },
      slotCon(str){
        this.btnBg = str
        this.content.sort((a,b)=>{
          if(str === 'id'){
            return parseInt(a.id, 16) - parseInt(b.id, 16)
          }
          return b[str] - a[str]
        })
      }
    }
  }
</script>

<style scoped>
  .btn-bg{
    background: #d0d8c0;
  }
  .order{
    margin-top: 50px;
  }

  .order ul{
    width: 1040px;
    height: 40px;
    margin: auto;
    padding: 0 20px;
    background-color: #9bb1bc;
    border-radius: 5px;
    line-height: 40px;
  }

  .order li{
    float: left;
    width: 80px;
    margin-right: 10px;
    cursor: pointer;
  }
  .order li:hover{
    color: #eee;
  }
</style>
