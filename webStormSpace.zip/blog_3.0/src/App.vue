<template>
  <div id="app">
    <loading></loading>
    <user></user>
    <header-con :styleClass="this.style" :scroll="scroll"></header-con>
    <router-view/>
    <footer-con @goToTop="goToTop" v-if="!(/admin/.test($route.path))" :friendLink="this.friendLink"></footer-con>

  </div>
</template>

<script>
  import Scroll from '@/assets/js/scroll.js'

  import {getData} from '@/api'

  import Loading from '@/common/loading'
  import User from '@/common/user'
  import HeaderCon from '@/common/header'
  import FooterCon from '@/common/footer'

  export default {
    name: 'App',
    data(){
      return {
        scroll:{},
        style:[],
        friendLink:[],
      }
    },
    components:{
      Loading,
      User,
      HeaderCon,
      FooterCon
    },
    created(){
      this.getData()
      setTimeout(()=>{
        if(this.isMove()){
          this.scroll = new Scroll(app)
          this.$store.commit('changeScrool', this.scroll)
        } else {
          document.body.style.overflowY = 'auto'
          this.$store.commit('changeIsMove', false)
        }
      })
    },

    updated(){
      this.goToTop()
    },

    methods:{
       async getData(){
        let {style,friendLink} = await getData()
         this.style = style
         this.friendLink = friendLink
      },

      goToTop(){
       if(!this.scroll) return
        setTimeout(()=>{
          if(this.$store.state.isMove){
            this.scroll.anima({
              top:0,
            },100)
          } else {
            document.documentElement.scrollTop = 0
          }
        })
      },

      isMove(){
        return navigator.userAgent.match(/iPhone|iPad|iPod|Android|BlackBerry|IEMobile/i)? false : true
      }
    }
  }
</script>

<style>

  html,body{
    height: 100%;
  }
  body,h1,h2,h3,h4,h5,h6,p,ul,ol,div,input,button,textarea,pre{
    margin: 0;
    padding: 0;
  }
  body{
    overflow: hidden;
    background: url('/static/img/all/bg.jpg');
    background-color: #eee;
    font-size: 14px;
    user-select: none;
    text-align: center;
    color: #666;
    font-family:'宋体','微软雅黑';
  }
  .clearfix:after{
    display: block;
    content: '';
    clear: both;
  }
  .clearfix{
    zoom: 1;
  }
  ul,ol{
    list-style: none;
    margin: 0;
    padding: 0;
  }
  a{
    text-decoration: none;
    color: inherit;
  }
  button{
    outline: none;
  }

  #app{
    position:absolute;
    top: 0;
    left: 0;
    width:100%;
    opacity: .96;
  }
</style>
