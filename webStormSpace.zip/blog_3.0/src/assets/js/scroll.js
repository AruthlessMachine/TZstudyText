export default class {
  constructor(el,num){
    this.el = el
    this.s = 0
    this.lineH = num || 120
    this.startTime = 0
    this.timer = ''
    this.changeValue = {}
    this.startValue = {}
    this.time = 0
    this.scrollHeader = true
    this.resize()
    window.addEventListener('resize',()=>{this.resize()})
    if(/Firefox/i.test(navigator.userAgent)){
      el.addEventListener('DOMMouseScroll',(e)=>{this.math(e)})
    } else {
      el.addEventListener('mousewheel',(e)=>{this.math(e)})
    }
  }

  resize(){
    this.h = window.innerHeight
  }

  math(e){
    if( this.h > this.el.offsetHeight ) return
    e.stopPropagation()
    clearTimeout(this.timer)

    if(e.wheelDeltaY > 0 || e.detail < 0){
      // 往上
      this.s += this.lineH
      this.scrollHeader = true
      if(this.s >= 0){
        this.s = 0
      }

    } else {
      this.scrollHeader = false
      this.s -= this.lineH
      if(this.s <= -(this.el.clientHeight-this.h)+this.lineH){
        this.s = -(this.el.clientHeight-this.h)
      }

    }

    this.timer = setTimeout(() => {
      this.anima({top: this.s})
    }, 20);

  }


  anima(obj = {},time = 160,cb){
    if(obj.top === 0) {
      this.scrollHeader = true
    }
    this.s  = obj.top
    this.time = time

    this.startTime = new Date()

    for (let i in obj) {
      this.val = parseInt(this.getStyle(this.el)[i])
      this.startValue[i] = isNaN(this.val) ? 0 : this.val
      this.changeValue[i] = this.s - this.startValue[i]
    }

      this.run(cb)
  }

  getStyle(){
    return this.el.currentStyle || getComputedStyle(this.el)
  }

  run(cb){
    let newTime = new Date() - this.startTime
    let t1 = newTime / this.time

    if (t1 >= 1) {
      t1 = 1
    } else {
      requestAnimationFrame(()=>{this.run()})
    }

    if (t1 === 1 && cb) cb()

    for (let i in this.changeValue) {
      let value = t1 * this.changeValue[i] + this.startValue[i]
      this.el.style[i] = value + 'px'
    }
  }

  // anima(obj = {},time = 160,cb){
  //   if(obj.top === 0) {
  //     this.scrollHeader = true
  //   }
  //   this.s  = obj.top
  //   this.time = time
  //
  //   this.startTime = new Date()
  //
  //   for (let i in obj) {
  //     this.el.style.transform.replace(/-?[0-9]+/,(num)=>{
  //       this.val = Number(num)
  //     })
  //
  //     this.startValue[i] = isNaN(this.val) ? 0 : this.val
  //     this.changeValue[i] = this.s - this.startValue[i]
  //   }
  //
  //   this.run(cb)
  // }
  //
  // getStyle(){
  //   return this.el.currentStyle || getComputedStyle(this.el)
  // }
  //
  // run(cb){
  //   let newTime = new Date() - this.startTime
  //   let t1 = newTime / this.time
  //
  //   if (t1 >= 1) {
  //     t1 = 1
  //   } else {
  //     requestAnimationFrame(()=>{this.run()})
  //   }
  //
  //   if (t1 === 1 && cb) cb()
  //
  //   for (let i in this.changeValue) {
  //     let value = t1 * this.changeValue[i] + this.startValue[i]
  //     this.el.style.transform = `translateY(${value}px)`
  //   }
  // }
}



