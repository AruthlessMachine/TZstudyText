import Vue from 'vue'
import Router from 'vue-router'

import Home from '@/components/home/home'
import List from '@/components/list/list'
import Article from '@/components/Article/article'
import Admin from '@/components/Admin/admin'

import Add from '@/components/Admin/base/add'
import DataList from '@/components/Admin/base/dataList'
import Update from '@/components/Admin/base/update'
import Upload from '@/components/Admin/base/uploadImg'


Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name:'home',
      component: Home
    },
    {
      path: '/list',
      name: 'list',
      component: List
    },
    {
      path: '/article',
      name: 'article',
      component: Article
    },
    {
      path: '/admin',
      name: 'admin',
      component: Admin,
      children:[
        {path: '/admin/add',component: Add},
        {path: '/admin/datalist',component: DataList},
        {path: '/admin/update',component: Update},
        {path: '/admin/upload',component: Upload},
      ]
    },
    {
      path: '*',
      redirect:'/'
    }
  ]
})
