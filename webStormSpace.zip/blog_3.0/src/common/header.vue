<template>
    <header>
      <div class='header' :class="{'header-boll':!scroll.scrollHeader && $store.state.isMove}">
      <div class='logo'>
        <router-link to="/">
          <span>XxX</span>
        </router-link>
      </div>
      <div class="header-style">
        <ul class='clearfix' v-if="$store.state.isMove">
          <li v-for="(item,index) in styleClass" ref="bgList" @click="changeBg(index)"><a>{{item.title}}</a></li>
        </ul>
      </div>
      <div class='search'><router-link to="/list" tag="span" class="iconfont icon-sousuo6"></router-link></div>
      <div class='user' @click="changeLogin"><span class="iconfont icon-ren" :class="{'login-color':$store.state.userList}"></span></div>
    </div>
    </header>
</template>

<script>
  export default {
    name:'headerCon',
    props:['styleClass','scroll'],
    data() {
      return {
        num:window.localStorage.getItem('blog_num') || 0
      }
    },
    mounted(){
      setTimeout(()=>{
        this.changeBg(this.num,true)
      },100)
    },
    methods:{
      changeBg(index,bool){

        if (this.num === index && !bool) return
        if(!bool){
          window.localStorage.setItem('blog_num',index)
          this.$router.go(0)
        }

        if (this.$refs.bgList){
          this.$refs.bgList[this.num].style.backgroundImage = null
          this.$refs.bgList[index].style.backgroundImage = `url(${this.styleClass[index].imageSrc})`
        } else {
          this.changeBg(this.num)
        }

        this.num = index
      },

      changeLogin(){
        if(this.$store.state.userList){
          this.$router.push({
            path:'/admin'
          })
        } else {
          setTimeout(()=>{
            this.$store.commit('changeloginShow',true)
          })
        }
      }
    }
  }
</script>

<style scoped>
  header{
  height: 50px;
  z-index: 996;
  background-color: #111;
  }
  .header{
    position: fixed;
    left: 0;
    top: 0;
    z-index: 996;
    width: 100%;
    height: 50px;
    background-color: #111;
    border-bottom: 1px solid #333;
    line-height: 50px;
    color: #aaa;
    box-shadow: 0 0 10px rgba(0,0,0,.5);
    transition:  top ease-out .3s;
  }
  .header-boll{
    top: -50px;
  }
  .header-style{
  display: flex;
  width: calc(100% - 200px);
  height: 100%;
  font-size: 12px;
  }
  .header ul li{
  flex: 1;
    background-position: center;
    background-size: cover;
  border-left: 1px solid #333;
  transition: background-color 1s;
  }
  .header ul li:hover{
  background-color: #fff;
  }
  .header ul a{
    display: block;

    cursor: pointer;
  }
  .header .logo{
    width: 100px;
    height: 100%;
  }
  .logo > a{
    display: inline-block;
    margin-top: 10px;
    height: 24px;
    line-height: 24px;
    font-size: 34px;
    font-weight: 700;
    border-radius: 30px;
    color: hsl(49, 100%, 72%);
    transform:rotateY(0deg);
    animation: run 5s infinite;
  }

  @keyframes run{
    from{
      transform:rotateY(0deg) scale(1);
    }
    50%{
      transform:rotateY(360deg) scale(.6);
    }
    to{
      transform:rotateY(0deg) scale(1);
    }
  }
  .header > *{
    float: left;
  }
  .header .search,.header .user{
  width: 50px;
  height: 100%;
  }
  .header .search span,.header .user span{
    display: inline-block;
    width: 100%;
    height: 100%;
    border-left: 1px solid #555;
    font-size: 24px;
    cursor: pointer;
  }

  .login-color{
    color: #0ab800;
  }
</style>
