<template>
  <div class="user" v-if="$store.state.loginShow">
    <div class="user-header clearfix">
      <p @click="changeShow(true)" :class="{'btn-color':isShow}">登录</p>
      <p @click="changeShow(false)" :class="{'btn-color':!isShow}">注册</p>
    </div>
    <div class="user-con">
      <div class="login-text" v-if="isShow">
        <div>
          <span>账号:</span>
          <input type="text" @blur="changeBorder(0)" @focus="changeBorder(1)" @keydown.enter="goLogin" v-model="user" placeholder="6-12位数字">
        </div>
        <div>
          <span>密码:</span>
          <input type="password" @blur="changeBorder(0)" @focus="changeBorder(1)" @keydown.enter="goLogin" v-model="password" placeholder="6-18位数字+字母">
        </div>
      </div>
      <div class="reg-text" v-if="!isShow">
        <div>
          <span>昵称:</span>
          <input type="text" @blur="changeBorder(0)" @focus="changeBorder(1)" @keydown.enter="goLogin" v-model="username" placeholder="1-12个字符">
        </div>
        <div>
          <span>账号:</span>
          <input type="text" @blur="changeBorder(0)" @focus="changeBorder(1)" @keydown.enter="goLogin" v-model="user" placeholder="6-12位数字">
        </div>
        <div>
          <span>密码:</span>
          <input type="password" @blur="changeBorder(0)" @focus="changeBorder(1)" @keydown.enter="goLogin" v-model="password" placeholder="6-18位数字+字母">
        </div>
      </div>
    </div>
    <div class="user-text">
      <p>{{text}}</p>
    </div>
    <div class="user-btn clearfix">
      <span @click="changeLogin">取消</span>
      <span @click="goLogin">{{btnText}}</span>
    </div>
  </div>
</template>

<script>
  import {login} from '@/api'
  export default {
    name:'user',
    data() {
      return {
        isShow:true,
        text:'',
        btnText:'登录',
        username:'',
        user:'',
        password:'',
        timer:null
      }
    },
    created(){
      setTimeout(()=>{
        let userList = JSON.parse(window.localStorage.getItem('blog_userList'))
        if(userList){
          this.user = userList.user
          this.password = userList.password
          this.goLogin()
        }
      })
    },
    methods:{
     changeShow(bool){
       if(bool){
         this.btnText = '登录'
       } else {
         this.btnText = '注册并登录'
       }
       this.isShow = bool
     },

      changeBorder(bool){
       if(bool){
         event.target.style.borderColor = '#aed1ff'
         this.text = ''
       } else {
         event.target.style.borderColor = '#eee'
       }
      },

      changeLogin(){
       this.username=this.user=this.password=''
        setTimeout(()=>{
          this.$store.commit('changeloginShow',false)
        })
      },

      goLogin(){
        if(new Date() - this.timer < 1000) return
        this.timer = new Date()

        this.username = this.username.trim()
        this.user = this.user.trim()

        if(!this.isShow){
          if(this.username == '' || this.user.length>12 || /\s/.test(this.username)){
            this.text = '你的昵称不符合规则！昵称由1-12位字符组成,且无空格换行符'
            return
          }
        }
        if (this.user == '' || this.user.length>12 || this.user.length<6 || isNaN(+this.user)) {
          this.text = '账号不能为空！且由6-18位数字组成'
          return
        } else if(this.password == '' || this.user.length>18 || this.user.length<6){
          this.text = '密码不能为空！且由6-18位数字+字母组成'
          return
        } else if (/\W|_/.test(this.password)) {
          this.text = '你的密码中包含除6-18位数字+字母以外的字符'
          return
        }

        login({
          username:this.username,
          user:this.user,
          password:this.password
        }).then((res)=>{
          if(res.err){
            if(this.isShow){
              this.text = '账号不存在或者密码错误了！'
            } else {
              this.text = '该账号已经被抢先注册了'
            }
          } else {
            this.text = '登录成功'
            setTimeout(()=>{
              this.changeLogin()
              this.$store.state.userList = true
              this.$store.commit('changeUserList',res.date)
              window.localStorage.setItem('blog_userList',JSON.stringify(res.date))
            },500)
          }
        })
      }
    }
  }
</script>

<style scoped>
  .btn-color{
    background-color: #0f88eb;
    color: #fff;
  }
 .user{
   overflow: hidden;
   position: fixed;
   left: 50%;
   top: 50%;
   z-index: 99999;
   width: 420px;
   background: #eee;
   transform: translate(-50%,-50%);
   border-radius: 4px;
   box-shadow: 0 0 20px 0 rgba(0,0,0,.5);
 }
  .user-header{
    background-color: #fff;
  }
  .user-header p{
    float: left;
    width: 50%;
    height: 36px;
    line-height: 36px;
    cursor: pointer;
  }

  .user-btn{
    padding: 10px 0 40px 0;
  }

 .user-btn span{
   display: inline-block;
   width: 90px;
   height: 42px;
   margin: 0 20px;
   line-height: 42px;
   background: #3c86ff;
   color: #fff;
   border-radius: 4px;
   cursor: pointer;
   
 }
 .user-btn span:first-child{
   background-color: #ff252f;
 }
 .user-btn span:hover{
   opacity: .8;
 }
  .user-text p{
    height: 24px;
    line-height: 24px;
    color: #ff252f;
    font-size: 12px;
  }
  
  .user-con{
    position: relative;
    height: 120px;
    margin-top: 10px;
  }
 .user-con>div{
   position: absolute;
   left: 0;
   top: 0;
   width: 100%;
   height: 100%;
   background-color: #eee;
 }

 .user-con>div>div{
   height: 30px;
   line-height: 30px;
   margin: 5px 0;
   font-size: 12px;
 }

 .user-con>div input{
   /*width: ;*/
   height: 24px;
   outline: none;
   border: 1px solid #eaeaea;
   text-indent: 10px;
   border-radius: 5px;
 }
</style>
