<template>
  <div class='project'>
    <div class='project-list' v-if="contentList.length">
      <div class='project-list-con' :class="{'project-move':!$store.state.isMove}">
        <ul class='clearfix'>
          <li v-for="item in contentList">
            <div>
              <router-link :to="{path:'/article',query:{id:item.id}}" tag="a">
                <div class='project-img' v-lazy:background-image="item.imageSrc"></div>
                <div class='project-describe'>
                  <div>
                    <h4><span>{{item.title}}</span></h4>
                    <div class="project-text">
                      <p>{{item.describe}}</p>
                    </div>
                    <span class='eyes'>
                       <span class="iconfont icon-chakan"></span>
                        <span>{{item.views}}</span>
                    </span>
                  </div>
                </div>
              </router-link>
            </div>
          </li>

        </ul>
      </div>
      <div class='project-btn' v-if="contentList.length !== length">
        <div>
          <a @click="getProject">
            <div class='ripple'>
              <span>获取更多</span>
              <i>({{contentList.length}}/{{length}})</i>
              <span>> > > </span>
            </div>
          </a>
        </div>
      </div>
    </div>
    <div class="project-none" v-if="!content.length">
      <span>很抱歉!没有一条数据...</span></br>
      <span class="get-more" @click="getMore">Get more!</span>
    </div>
  </div>
</template>

<script>
  import {getProjectData} from '@/api'

  export default {
    name:'projectList',
    props:['content','length'],
    data() {
        return {
          contentList:[],
          num:1
        }
    },
    created(){

    },
    watch:{
      content(){
        this.contentList = this.content
      }
    },
    methods:{
      async getProject(){
        let {content} = await getProjectData({num:this.num})
        this.contentList.push(...content)
        this.num++
      },
      getMore(){
        this.$router.push({
          path:'/list'
        })
        this.$router.go(0)
      }
    }
  }

</script>

<style scoped>
  .project-list{
    max-width: 1100px;
    margin: auto;
  }
  .project-none{
    height: 30px;
    margin-top: 20px;
    line-height: 30px;
    font-size: 20px;
  }

  .get-more{
    cursor: pointer;
  }
  .project-list-con{
    padding: 50px 0;
  }

  .project-list-con > ul{
    text-align: center;
  }
  .project-list-con ul li{
    overflow: hidden;
    float: left;
    display: inline-block;
    width: 250px;
    height: 350px;
    margin: 0 12.5px 30px;
  }

  .project-move ul li{
    float: none;
  }
  .project-list-con li > div{
    height: 100%;
  }

  .project-img{
    height: 100%;
    background-size: cover;
    background-position: center;
    border-radius: 4px;
    transition: height .4s;
  }

  .project-describe{
    height: 150px;
    padding: 0 10px;

  }

  .project-describe > div{
    position: relative;
    height: 100%;
    margin-top: -30px;
    background-color: rgb(245, 235, 189);
    border-radius: 4px;
    box-shadow: 0 0 2px 0 rgba(0,0,0,.5);
    transition: box-shadow .8s cubic-bezier(.21,1.02,.62,-0.18);
  }

  .project-describe h4{
    padding: 0 60px 0 20px;
  }
  .project-describe h4 span{
    display: block;
    overflow: hidden;
    height: 30px;
    line-height: 30px;
    text-align: left;
    color:#444;
  }
  .project-list-con li:hover .project-describe > div{
    box-shadow: 0 8px 10px 0 rgba(0,0,0,.5);
  }

  .project-list-con li:hover .project-img{
    height: 200px;
  }

  .project-describe .eyes{
    position: absolute;
    top: 0;
    right: 10px;
    height: 30px;
    line-height: 30px;
    font-size: 14px;
    color: #ff94d5;
  }
  .project-describe .eyes span{
    vertical-align: top;
  }
  .project-describe .project-text{
    padding: 10px 15px;
  }
  .project-text p{
    overflow: hidden;
    height: 100px;
    line-height: 20px;
    font-size: 14px;
    letter-spacing:1px;
    word-break:break-all;

  }

  .project-btn{
    height: 80px;
    padding: 10px 150px;
  }

  .project-btn > div{
    overflow: hidden;
    position: relative;
    height: 100%;
    background-image: linear-gradient(to right,rgb(204, 85, 149), rgb(204, 85, 120),rgb(204, 85, 149));
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,.5)
  }

  .project-btn a{
    display: block;
    height: 100%;
    font-size: 16px;
    color: #eee;
    line-height: 80px;
    cursor: pointer;
  }

  .project-btn i{
    font-style: normal;
    color: rgb(223, 241, 63);
  }

  .ripple::before{
    content: '';
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%,-50%);
    width: 0;
    height: 0;
    border: 400px solid rgba(200,200,200,.1);
    background-color: transparent;
    border-radius: 100%;
    opacity: 0;
  }

  .project-btn > div:hover .ripple::before{
    transition: width .6s cubic-bezier(.11,.62,.59,.94) , height .5s cubic-bezier(.11,.62,.59,.94) ;
    opacity: 1;
    width: 1000px;
    height: 800px;
  }

</style>
