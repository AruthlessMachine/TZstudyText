<template>
    <div class="fast-entrance">
      <div class="entrance">
        <div class="entrance-header">
          <h3>虫洞</h3>
        </div>
        <ul class="entrance-con clearfix">
          <li v-for="item in shortcut">
            <a :href="item.linkSrc" target="_blank">
              <div>
                <img v-lazy="item.imageSrc" alt="">
              </div>
              <p>{{item.title}}</p>
            </a>
          </li>
        </ul>
      </div>
      
    </div>
</template>

<script>
  export default {
    name:'FastEntrance',
    props:['shortcut'],
    data() {
      return {}
    }
  }
</script>

<style scoped>
  .fast-entrance{
    margin-top: 50px;
  }
  
  .entrance{
    padding: 20px;
    background: #fff8;
  }
  .entrance-header{
    border-bottom: 1px solid #bbb;
  }
  .entrance-header h3{
    height: 40px;
    line-height: 40px;
    font-size: 24px;
    color: #fff;
    text-align: left;
    text-indent: 15px;
    font-weight: normal;
    text-shadow: 2px 3px 2px #000;
  }
  .entrance-con{
    margin-top: 15px;
  }

  .entrance-con li{
    float: left;
    width: 70px;
    margin-right: 10px;
    margin-bottom: 15px;
    border-radius: 5px;
    box-shadow: 0 0 3px 0 rgba(0,0,0,.5);
    transition: box-shadow 1s cubic-bezier(.21,1.02,.62,-0.18),transform .3s;
  }
  .entrance-con li:hover{
    box-shadow: 5px 20px 10px 0 rgba(0,0,0,.5);
    transform: translateY(-3px);
  }

  .entrance-con li:nth-of-type(4n){
    margin-right: 0;
  }
  .entrance-con li div{
    overflow: hidden;
    height: 70px;
    border-radius: 5px;
  }

  .entrance-con li img{
    width: 100%;
  }

  .entrance-con li p{
    overflow: hidden;
    height: 20px;
    font-size: 16px;
    line-height: 20px;
  }
</style>
