<template>
    <div v-if='$store.state.lodShow' class="loading" @mousewheel.stop @DOMMouseScroll.stop>
      <span>
        <i></i>
        <i></i>
      </span>
    </div>
</template>

<script>
  export default {
    name:'loading',
    data() {
      return {}
    }
  }
</script>

<style scoped>
  .loading{
    position: fixed;
    z-index: 9999;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background: #000;
    opacity: .93;
  }
  
  .loading span{
    overflow: hidden;
    position: absolute;
    left: 50%;
    top: 50%;
    width: 600px;
    height: 2px;
    background-color: #333;
    transform: translate(-50%,-50%);
    box-shadow: 0 0 2px 0 #fff;
    border-radius: 5px;
  }

  .loading span i{
    position: absolute;
    left: -50px;
    width: 100px;
    height: 2px;
    background: #ccc;
    border-radius: 5px;
    animation: run 1s infinite;
  }
  .loading span i:last-child {
    animation-delay: .3s;
  }
  @keyframes run {
    from{
      left: -50px;
    }
    to{
      left: 600px;
    }
  }
</style>
