<template>
    <div class='like-header' v-if="authorSay">
      <div class='scale' v-lazy:background-image="authorSay.imageSrc" ></div>
      <!--:style="{'background-image':`url(${authorSay.imageSrc})`}"-->
      <div class='like-header-con'>
        <div>
          <h3>{{authorSay.title}}</h3>
          <p>{{authorSay.describe}}</p>
          <div class='like-text'>
            <div>
              <p>{{authorSay.content}}</p>
            </div>

          </div>

          <div class='like-btn'>
            <router-link to="./list" tag="button">Get more</router-link>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
  export default {
    name:'likeHeader',
    props:['authorSay'],
    data() {
        return {}
    }
  }
</script>

<style scoped>
  .like-header{
    position: relative;
    overflow: hidden;
    height: 430px;
  }
  .like-header > div{
    height: 100%;
  }
  .like-header > .scale{
    background-position: center;
    background-size: cover;
    transition: transform 3s;
  }

  .like-header > .like-header-con{
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(30, 30, 30, .9);
  }

  .like-header:hover > .scale{
    transform: scale(1.1);
  }

  .like-header-con > div{
    max-width: 1000px;
    margin: auto;
    padding: 50px 0 30px;
  }

  .like-header-con > div h3{
    overflow: hidden;
    height: 60px;
    line-height: 60px;
    font-size: 48px;
    color: #eee;
  }
  .like-header-con > div > p{
    overflow: hidden;
    height: 20px;
    line-height: 20px;
    font-size: 12px;
  }

  .like-header-con .like-text{
    overflow: hidden;
    width: 80%;
    height: 150px;
    margin: 20px auto 0;
    padding: 15px 30px;
    border: 1px solid #666;
    line-height: 30px;
    font-size: 14px;
    color: #fff;
    border-radius: 5px;
  }
  .like-header-con .like-text > div{
    overflow: hidden;
    display: flex;
    align-content:center;
    height: 100%;
  }
  .like-header-con .like-text p {
    margin: auto
  }
  .like-btn{
    position: relative;
    margin-top: 20px;
  }
  .like-btn button{
    width: 300px;
    height: 50px;
    border: 1px solid #aaa;
    background-color: transparent;
    border-radius: 3px;
    color: #aaa;
    font-size: 16px;
    cursor: pointer;
    transition: border-color .5s,color .5s;
  }

  .like-btn button:hover{
    border-color: #fff;
    color: #fff;
  }
</style>
