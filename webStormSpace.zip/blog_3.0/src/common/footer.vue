<template>
  <footer>
    <div class='footer-con'>
      <div class='footer-list'>
        <h5>友链：</h5>
        <p>
          <a v-for='item in friendLink' :href="item.linkSrc" target="_blank">{{item.title}}</a>
        </p>
      </div>
      <div class='author-contact'>
        <span>微信：wangxinzyy</span>
        <span>企鹅: 1418269577</span>
        <span>企鹅群: 618621721</span>
        <span>图片素材来源网络，侵删！</span>
      </div>
      <div class='footer-bottom'>
        <p><a href="">苏ICP备19019789号-1</a></p>
      </div>
      <div class='to-top iconfont icon-jiantouarrow499' @click="toTop"></div>
    </div>
  </footer>
</template>

<script>
  export default {
    name:'footerCon',
    props:['friendLink'],
    data() {
        return {}
    },

    methods:{
      toTop(){
        this.$emit('goToTop')
      }
    },

  }
</script>

<style scoped>
  footer{
    margin-top: 150px;
    padding: 30px 0 10px;
    background-image: repeating-linear-gradient(-20deg,#111,#111 10px,#1e1e20 0,#1e1e20 12px);
  }

  .footer-con{
    position: relative;
    max-width: 1100px;
    height: 100%;
    margin: auto;
  }
  .footer-bottom{
    margin-top: 30px;
    padding: 10px 0;

  }
  .footer-bottom p{
    height: 20px;
    line-height: 20px;
  }

  .footer-list{
    text-align: left;
  }
  .footer-list h5{
    border-bottom: 1px solid #999;
    text-indent: 10px;
    font-size: 18px;
    font-weight: normal;
  }
  .footer-list p{
    padding: 10px;
  }
  .footer-list p > a{
    display: inline-block;
    height: 20px;
    padding: 0 10px;
    font-size: 16px;
    line-height: 20px;
  }

  .footer-list p > a:hover{
    color: #fff;
  }

  .author-contact{
    padding: 20px;
    text-align: left;
  }

  .to-top{
    position: absolute;
    top: -20px;
    right: 20px;
    width: 80px;
    height: 30px;
    border: 1px solid #666;
    background-color: #0008;
    line-height: 30px;
    transition: 1s;
    border-radius: 4px;
    cursor: pointer;
  }

  .to-top:hover{
    border-color:#fff;
    background-color: #fff;
  }
</style>
