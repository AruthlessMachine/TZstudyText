import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

  export default new Vuex.Store({
    state:{
      userList: null,
      comSwitch: 0,
      lodShow:true,
      goScrool: {},
      loginShow:false,
      isMove:true,
    },
    mutations:{
      changeIsMove(state,bool){
        state.isMove = bool
      },

      changeUserList(state,date){
        state.userList = date
      },

      changeSwitch(state,comSwitch){
        state.comSwitch = comSwitch
      },

      changeScrool(state,scrool){
        state.goScrool = scrool
      },

      changelodShow(state,lodShow){
        state.lodShow = lodShow
      },
      changeloginShow(state,bool){
        state.loginShow = bool
      }
    }
  })
