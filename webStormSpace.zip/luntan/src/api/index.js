import axios from 'axios'

const URL = 'https://cnodejs.org/api/v1/'

axios.interceptors.response.use(function (response) {
    return response.data
});

export async function getHomeData(data) {
    return await axios.get(URL+`topics?tab=${data.tab}&limit=12&page=${data.page}`)
}

export async function getDetailData(id) {
    return await axios.get(URL+`topic/${id}`)
}