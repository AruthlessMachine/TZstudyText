import React, {Component} from 'react';

export default class  extends Component {

    render() {
        let {id} = this.props.match.params

        return (
            <div>
                user{id}
            </div>
        );
    }
}

