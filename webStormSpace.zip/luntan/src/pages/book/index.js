import React, {Component} from 'react';
import data from './data.js'

import Card from '@/components/card'


export default class extends Component {
    render() {
        return (
            <div>
                {
                    data.map((item,index)=>(
                        <Card key={index} {...item}/>
                    ))
                }
            </div>
        );
    }
}