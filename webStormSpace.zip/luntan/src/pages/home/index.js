import React, {Component} from 'react';
import {Col, Layout, Row} from "antd";
import './index.css'

import MenuLeft from '@/components/menuLeft'
import ConList from '@/components/list'

import {getHomeData} from '@/api'
export default class extends Component {
    state = {
        data:[],
        id:this.props.match.params.id,
        isLoding:true,
        pageList:{
            all:1,
            good:1,
            ask:1,
            share:1,
            job:1,
            dev:1
        }
    }

    componentWillMount(){
        this._getData(this.state.id,1)
    }

    shouldComponentUpdate(nextProps,nextState){
        let {id} = nextProps.match.params
        if( id !== this.state.id ){
            this.setState({
                id,
                isLoding:true
            })
            this._getData(id,this.state.pageList[id])
        }

        return true
    }

    async _getData(tab,page){
        let {data} = await getHomeData({
            tab,
            page
        })

        this.setState({
            data,
            isLoding:false
        })
    }

    handleChangePage = page=>{
        let {id,pageList} = this.state
        if( pageList[id] === page ) return

        let newPageList = pageList
        newPageList[id] = page

        this.setState({
            pageList: newPageList,
            isLoding:true
        })
        this._getData(id,page)

    }

    render() {
        let {id,data,isLoding,pageList} = this.state
        return (
            <div>
                <Layout.Content>
                    <Row justify={'space-between'}>
                        <Col className={'col-menu'} md={6}>
                            <MenuLeft id={id}/>
                        </Col>
                        <Col className={'col-content'} md={18}>
                            <ConList
                                data={data}
                                isLoding={isLoding}
                                currPage={pageList[id]}
                                ChangePage={this.handleChangePage}/>
                        </Col>
                    </Row>
                </Layout.Content>
            </div>
        );
    }
}

