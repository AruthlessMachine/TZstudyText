import React, {Component} from 'react';

import CardDetails from '@/components/cardDetails'
import Replies from '@/components/replies'
import CardLoading from '@/components/cardLoading'

import './index.css'

import {getDetailData} from '@/api'

export default class  extends Component {

    state={
        data:{}
    }

    componentWillMount(){
        this._getData()
    }

    async _getData(){
        let {id} = this.props.match.params
        let {data} = await getDetailData(id)
        this.setState({
            data
        })
    }

    render() {
        let {data} = this.state
        let boll = Object.keys(data).length

        return (
            <div>
                <CardLoading isLoading={!boll}/>

                {
                    boll && (
                        <div>
                            <CardDetails data={data}/>
                            <Replies replies={data.replies} />
                        </div>
                    )

                }
            </div>
        )
    }
}

