import React from 'react';
import {Layout} from 'antd';

import Router from './router'
import '@/App.css';


import Header from '@/components/header'
import Fotter from '@/components/fotter'




export default function App() {
    return (

        <div className="App">
            <Layout>
                <Header></Header>
                <div className={'content-con'}>
                    <Router/>
                </div>
                <Fotter></Fotter>
            </Layout>
        </div>
    );
}

