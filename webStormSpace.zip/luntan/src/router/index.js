import React, {Component} from 'react';
import {
    Route,
    Switch,
    Redirect
} from "react-router-dom";
import Home from '@/pages/home'
import Book from '@/pages/book'
import About from '@/pages/about'
import User from '@/pages/user'
import Details from '@/pages/details'

export default class extends Component {
    render() {
        return (
            <Switch>
                <Route exact path={'/index/:id'} component={Home} />
                <Route exact path={'/book'} component={Book} />
                <Route exact path={'/about'} component={About} />
                <Route exact path={'/user/:id'} component={User} />
                <Route exact path={'/details/:id'} component={Details} />
                <Route
                    render={()=>(
                        <Redirect exact to={'/index/all'} />
                    )}
                />
            </Switch>
        )
    }
}

