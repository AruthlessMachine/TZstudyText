import React, {Component} from 'react';
import {Menu} from "antd";
import {NavLink} from "react-router-dom";
import './index.css'

export default class  extends Component {
    state = {
        current:'all',
        width:0
    }
    componentWillMount(){
        let width = window.innerWidth
        this.setState({
            width,
            current:this.props.id
        })
    }
    handleClick = e =>{
        this.setState({
            current:e.key
        })
    }
    render() {
        let {width} = this.state
        return (
            <Menu className={'menu'}
                  mode={width<=768?'horizontal':'inline'}
                  onClick={this.handleClick}
                  selectedKeys={[this.state.current]}
                  theme={'light'}>
                <Menu.Item key={'all'}>
                    <NavLink to={'/index/all'}>
                        全部
                    </NavLink>
                </Menu.Item>
                <Menu.Item key={'good'}>
                    <NavLink to={'/index/good'}>
                        精华
                    </NavLink>
                </Menu.Item>
                <Menu.Item key={'ask'}>
                    <NavLink to={'/index/ask'}>
                        问答
                    </NavLink>
                </Menu.Item>
                <Menu.Item key={'share'}>
                    <NavLink to={'/index/share'}>
                        分享
                    </NavLink>
                </Menu.Item>
                <Menu.Item key={'job'}>
                    <NavLink to={'/index/job'}>
                        招聘
                    </NavLink>
                </Menu.Item>
                <Menu.Item key={'dev'}>
                    <NavLink to={'/index/dev'}>
                        测试
                    </NavLink>
                </Menu.Item>
            </Menu>
        );
    }
}

