import React, {Component} from 'react';
import {Layout} from "antd";
import './index.css'
export default class  extends Component {
    render() {
        return (
            <Layout.Footer className={'fotter'}>苏ICP备19019789号-1</Layout.Footer>
        );
    }
}
