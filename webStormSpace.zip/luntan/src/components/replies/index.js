import React, {Component} from 'react';
import {List} from 'antd'

import './index.css'

import UserMessage from '@/components/userMessage'
export default class  extends Component {
    render() {
        let {replies} = this.props
        return (
            <ul style={{padding:'16px 24px'}}>
                <List
                    itemLayout="vertical"
                    dataSource={replies}
                    renderItem={item=>(
                        <List.Item
                            extra={item.ups.length?`有${item.ups.length}个人赞了这条回复`:''}
                        >
                            <List.Item.Meta
                                title={
                                    <UserMessage item={item}/>
                                }
                            />
                            <div
                                dangerouslySetInnerHTML={{
                                    __html:item.content
                                }}
                            >
                            </div>
                        </List.Item>
                    )}
                />
            </ul>
        )
    }
}

