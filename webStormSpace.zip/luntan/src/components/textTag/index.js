import React, {Component} from 'react';
import {
    Tag
} from 'antd'

const LIST_TAB = {
    top:{
        txt:'置顶',
        color:'cyan'

    },
    good:{
        txt:'精华',
        color:'red'
    },
    ask:{
        txt:'问答',
        color:'magenta'
    },
    share:{
        txt:'分享',
        color:'orange'
    },
    job:{
        txt:'招聘',
        color:'gold'
    },
    dev:{
        txt:'测试',
        color:'purple'
    }
}

export default class  extends Component {

    _getTab(data){
        let str = data.top?'top':data.good?'good':data.tab
        if(str){
            return {txt:LIST_TAB[str].txt,color:LIST_TAB[str].color}
        } else {
            return {txt:'share'.txt,color:'orange'}
        }
    }

    render() {
        let {data} = this.props
        let {txt,color} = this._getTab(data)
        return (
            <Tag color={color}>{txt}</Tag>
        );
    }
}

