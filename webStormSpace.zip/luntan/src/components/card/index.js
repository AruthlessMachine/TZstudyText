import React, {Component} from 'react';
import {Card} from 'antd'
import './index.css'


export default class  extends Component {
    render() {
        let {title,content,className} = this.props
        return (
            <Card type="inner" title={title}>
                <div
                    className={className && className}
                    dangerouslySetInnerHTML={{
                        __html:content
                    }}
                >
                </div>
            </Card>
        );
    }
}

