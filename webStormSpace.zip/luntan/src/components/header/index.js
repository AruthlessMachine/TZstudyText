import React, {Component} from 'react';
import {Col, Icon, Layout, Menu, Row} from "antd";
import {NavLink} from "react-router-dom";
import './index.css'

export default class  extends Component {
    state = {
        current:'home'
    }

    handleClick = e =>{
        this.setState({
            current:e.key
        })
    }
    render() {
        return (
            <Layout.Header>
                <Row>
                    <Col md={6}>
                        <h1 id={'logo'}>discussion</h1>
                    </Col>
                    <Col md={18}>
                        <div>
                            <Menu
                                className={'menu-con'}
                                onClick={this.handleClick}
                                selectedKeys={[this.state.current]}
                                mode={'horizontal'}>
                                <Menu.Item key={'home'} >
                                    <NavLink to={'/index/all'}>
                                        <Icon type="home" />
                                        首页
                                    </NavLink>
                                </Menu.Item>
                                <Menu.Item key={'book'}>
                                    <NavLink to={'/book'}>
                                        <Icon type="book" />
                                        教程
                                    </NavLink>
                                </Menu.Item>
                                <Menu.Item key={'about'}>
                                    <NavLink to={'/about'}>
                                        <Icon type="like" />
                                        关于
                                    </NavLink>
                                </Menu.Item>
                            </Menu>
                        </div>
                    </Col>
                </Row>
            </Layout.Header>
        );
    }
}

