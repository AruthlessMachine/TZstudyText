import React, {Component} from 'react';
import {Avatar} from "antd";
import {NavLink} from "react-router-dom";

export default class  extends Component {
    render() {
        let {author,id,create_at} = this.props.item
        return (
            <div style={{display:'inline-block'}}>
                <Avatar
                    style={{marginRight:'10px'}}
                    src={author.avatar_url}
                ></Avatar>
                <NavLink to={'/user/'+author.loginname}>{author.loginname}</NavLink>
                <span>
                    发表于：
                </span>
                <span>{create_at.split('T')[0]}</span>
            </div>
        );
    }
}

