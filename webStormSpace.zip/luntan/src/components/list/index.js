import React, {Component} from 'react';
import {NavLink} from 'react-router-dom'
import {
    List,
    Avatar
} from 'antd'
import './index.css'

import TextTag from '@/components/textTag'

export default class  extends Component {
    render() {
        let {data,isLoding,ChangePage,currPage} = this.props

        return (
            <div className={'list-con'}>
                <List
                    loading={isLoding}
                    pagination={{
                        current:currPage,
                        pageSize:12,
                        total:800,
                        onChange(page){
                            ChangePage(page)
                        }
                    }}
                    dataSource={data}
                    itemLayout={'vertical'}
                    renderItem={item=>(
                        <List.Item
                            actions={['回复:'+item.visit_count,'访问:'+item.reply_count]}
                        >
                            <List.Item.Meta
                                avatar={
                                    // "https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png"
                                    <Avatar src={item.author.avatar_url} />
                                }
                                description={
                                    <div>
                                        <NavLink to={'/user/'+ item.author.loginname}>{item.author.loginname}</NavLink>
                                        发表于:{item.create_at.split('T')[0]}
                                    </div>
                                }
                                title={
                                    <div>
                                        <TextTag data={item}></TextTag>
                                        <NavLink to={'/details/'+ item.id}>{item.title}</NavLink>
                                    </div>
                                }
                            />
                        </List.Item>
                    )}
                />
            </div>
        );
    }
}

