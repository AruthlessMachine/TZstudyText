import React, {Component} from 'react';
import {Card,Skeleton } from "antd";

export default class  extends Component {
    render() {
        let {isLoading} = this.props
        return (
            <div style={{marginTop:30}}>
                <Skeleton
                    avatar paragraph={{ rows: 10}} loading={isLoading} title />
            </div>

        );
    }
}

