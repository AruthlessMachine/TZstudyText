import React, {Component} from 'react';
import {Card} from 'antd'

import TextTag from '@/components/textTag'
import UserMessage from '@/components/userMessage'

export default class  extends Component {
    render() {
        let {title,content} = this.props.data
        console.log(this.props.data)
        return (
            <Card title={
                <div>
                    <h2>{title}</h2>
                    <TextTag data={this.props.data} />
                    <UserMessage item={this.props.data} />
                </div>

            }>

                <div dangerouslySetInnerHTML={{
                    __html:content
                }}>

                </div>
            </Card>
        );
    }
}

