<template>
    <el-card id="login">
      <h1>VUEX练习</h1>
      <el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-form-item label="用户名" prop="admin">
          <el-input type="text" v-model="ruleForm.admin" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="pass">
          <el-input type="password" v-model="ruleForm.pass" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm('ruleForm')">登录</el-button>
          <el-button @click="resetForm('ruleForm')">注册</el-button>
        </el-form-item>
      </el-form>
    </el-card>
</template>

<script>
  export default {
    data() {
      var checkAdmin = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('用户名不能为空'));
        }
        setTimeout(() => {
          if (!Number.isInteger(+value)) {
            callback(new Error('请输入数字值'));
          } else {
            if (value.length < 18 && value.length > 12) {
              callback(new Error('不大于18个字符且不小于8字符'));
            } else {
              callback();
            }
          }
        }, 500);
      };

      return {
        ruleForm: {
          admin: '',
          pass: '',
        },
        rules: {
          admin: [
            { validator: checkAdmin, trigger: 'blur' }
          ],
          pass: [
            {required: true, message: '请输入密码', trigger: 'blur' }
          ],
        }
      };
    },
    methods: {
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {

            this.$axios.post('/api/login', {
              admin: this.ruleForm.admin,
              pass: this.ruleForm.pass
            }).then(res => {

              if(res.data.errno){
                this.$message.error('错了哦！账户不存在，或者密码错误');
              } else {
                this.$message({
                  message: '恭喜你！登录成功',
                  type: 'success'
                });

                this.$store.commit('saveLoginUser',this.ruleForm.admin)

                this.$router.push('/admin')
              }
            })
          }
        });
      },
      resetForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$axios.post('/api/register', {
              admin: this.ruleForm.admin,
              pass: this.ruleForm.pass
            }).then(res => {
              if(res.data.errno){
                this.$message.error('注册失败，账号已经被注册了！');
              }else{
                this.$message({
                  message: '注册成功',
                  type: 'success'
                });
              }
            })
          }
        })
      }
    }
  }
</script>

<style scoped>
  h1{
    text-align: center;
    margin-bottom: 20px;
  }
  #login {
    position: fixed;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    width: 500px;
    height: 250px;
    padding: 20px 30px 40px 0px;
    margin: auto;
    box-shadow: 0 0 10px 0 blue;
  }

  #login h3 {
    font-size: 28px;
    text-align: center;
    line-height: 70px;
  }
</style>
