const express = require('express')
const bodyParser = require('body-parser')
const mongoose = require('mongoose')
const Users = require('./schema/users')

const app = express()

app.use(bodyParser.urlencoded({extended:true}))
app.use(bodyParser.json())

app.use('/login',(req,res)=>{
  let {admin,pass} = req.body

  Users.findOne({admin,pass})
    .then((data)=>{
      if(data){
        res.send({
          errno:0
        })
      } else {
        res.send({
          errno:1
        })
      }
    })


})

app.use('/register',(req,res)=>{
  let {admin,pass} = req.body

  Users.findOne({
    admin,
  }).then(user=>{
    if(user){ //如果找到该用户  则用户已经注册过了  不可注册  返回1
      res.send({
        errno:1
      })
    }else{  //如果没找到该用户  则用户没有注册过  可以注册  返回0
      res.send({
        errno:0
      })

      new Users({ //保存该用户
        admin,
        pass,
        age:~~(Math.random()*20)+20
      }).save()
    }
  })
});

app.get('/admin/userlist',(req,res)=>{
  Users.find().then(users=>{
    res.send(users)
  })
})

mongoose.connect('mongodb://localhost:27017/vuex',{useNewUrlParser: true},(err)=>{
  if (err) {
    console.log('数据库链接失败')
    return
  }
  app.listen(3000,()=>{
    console.log('3000端口监视完成')
  })
  console.log('数据库链接成功')
})
