const mongoose = require('mongoose')

const userSchema = new mongoose.Schema({
  admin:String,
  pass:String,
  age:Number
})

module.exports = mongoose.model('users',userSchema)
