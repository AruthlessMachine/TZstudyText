<template>
    <div class="detail">
      <Week-header></Week-header>
      <div ref='list' class="detail-list">
          <Week-list :weekInfo="weekInfo"></Week-list>
        </div>
    </div>
</template>

<script>
  import {getWeek} from '@/api'

  import WeekHeader from './base/header'
  import WeekList from './base/list'

  import BScroll from 'better-scroll'
  export default {
    name:'Detail',
    data() {
      return {
        weekInfo:[]
      }
    },
    components:{
      WeekHeader,
      WeekList,
    },
    created(){
      this.getdata()
    },
    methods:{
      async getdata(){
        let {weekInfo} = await getWeek(this.$route.params.id)
        this.weekInfo = weekInfo
      },

    },
    mounted(){
      this.scroll = new BScroll(this.$refs.list,{
        click:true
      })
    }
  }
</script>

<style scoped>
  .detail-list{
    overflow: hidden;
    position: fixed;
    left: 0;
    top: .86rem;
    right: 0;
    bottom: 0;
    background-color: #fff;
  }

</style>
