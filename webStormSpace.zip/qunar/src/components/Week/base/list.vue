<template>
    <div class="list">
      <ul>
        <router-link
          to=""
          tag="li"
          v-for="(item,index) in weekInfo"
          :key="index"
        >
          <div class="list-img">
            <img :src="item.imgUrl" alt="">
          </div>
          <div class="list-text">
            <h3>
              <p class="list-title">{{item.title}}</p>
            </h3>
            <p class="list-price">
              <i>¥</i>
              <span class="price-mark">{{item.price}}</span>
              <i>起</i>
            </p>
            <p class="list-com">{{item.desc}}</p>
          </div>
        </router-link>
      </ul>
    </div>
</template>

<script>
  export default {
    name:'WeekList',
    props:['weekInfo'],
    data() {
      return {

      }
    }
  }
</script>

<style scoped>
  .list li{
    border-bottom: .2rem solid #eee;
  }
  .list-img{
    overflow: hidden;
    width: 100%;
    height: 3rem;
  }
  .list-img img{
    width: 100%;
  }
  .list-text{
    position: relative;
    padding: .14rem .2rem .24rem;
  }
  .list-title{
    overflow: hidden;
    height: .54rem;
    line-height: .54rem;
    color: #212121;
    font-size: .36rem;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .list-com{
    overflow: hidden;
    height: .45rem;
    padding-right: .3rem;
    line-height: .45rem;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .list-price{
    position: absolute;
    right: .2rem;
    top: .25rem;
    font-size: 0;
  }
  .list-price i{
    font-size: .24rem;
  }
  .list-price i:first-of-type,.price-mark{
    color: #ff8300;
  }
  .list-price .price-mark{
    font-size: .4rem;
  }
</style>
