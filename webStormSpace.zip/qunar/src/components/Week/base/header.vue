<template>
    <div class="header">
      <div class="header-fixed">
        <router-link
          class='iconfont icon-fanhui header-back'
          tag="i"
          to="/"></router-link>
        <h2>{{this.$store.state.title}}</h2>
      </div>
    </div>
</template>

<script>
  export default {
    name:"WeekHeader",
    data() {
      return {

      }
    }
  }
</script>

<style scoped>

  .header-fixed{
    position:relative;
    background:#00bcd4;
    line-height:.86rem;
    color:#fff;
    text-align:center;
  }
  .header-back{
    position:absolute;
    left:0;
    top:0;
    width:.8rem;
    color:#fff;
  }

  .header-fixed h2{
    text-align:center;
    font-size:.32rem;
  }
</style>
