<template>
  <div class="home">
    <home-header></home-header>
    <div ref='homeList' class="home-list">
      <div>
        <home-swiper :swiperList='swiperList'></home-swiper>
        <home-nav :iconList='iconList'></home-nav>
        <home-favourite :recommendList="recommendList"></home-favourite>
        <home-weekend :weekendList="weekendList"></home-weekend>
      </div>
    </div>
  </div>
</template>

<script>
import {getHome} from '@/api'

import HomeHeader from './base/header'
import HomeSwiper from './base/swiper'
import HomeNav from './base/nav'
import HomeFavourite from './base/favourite'
import HomeWeekend from './base/weekend'

import BScroll from 'better-scroll'

export default {
  name: 'Home',
  data () {
    return {
      iconList:[],
      recommendList:[],
      swiperList:[],
      weekendList:[]
    }
  },
  components:{
    HomeHeader,
    HomeSwiper,
    HomeNav,
    HomeFavourite,
    HomeWeekend
  },
  created(){
    this.getData()
  },
  methods:{
    async getData(){
      let {iconList,recommendList,swiperList,weekendList} = await getHome()
      this.iconList = iconList
      this.recommendList = recommendList
      this.swiperList = swiperList
      this.weekendList = weekendList
    }
  },
  mounted(){
    this.scroll = new BScroll(this.$refs.homeList,{
      click:true,
    })
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .home-list{
    overflow: hidden;
    position: fixed;
    left: 0;
    top: .86rem;
    right: 0;
    bottom: 0;
    background-color: #fff;
  }
</style>
