<template>
  <div class="favourite">
    <h2>猜你喜欢</h2>
    <ul class="clearfix">
      <router-link
        :to="{name:'Detail',params:{id:itme.id}}"
        tag="li"
        class="clearfix"
        v-for="itme in recommendList"
        :key="itme.id">
        <div class="fav-img">
          <img :src="itme.imgUrl" alt="">
        </div>
        <div class="fav-info">
          <div>
            <h3>{{itme.title}}</h3>
          </div>
          <div class="scroe">
            <span class="start">
              <i class="iconfont icon-star" v-for="i in 5"></i>
              <span class="scroe-top" ref="scroe" :style="itme.score | clacWidth">
                <i class="iconfont icon-star" v-for="i in 5"></i>
              </span>
            </span>
            <span class="comment">{{itme.comment}}条评论</span>
          </div>
          <div class="price">
            <span class="mark">
              <i class="mark-on">¥</i>
              <i class="mark-price">{{itme.price}}</i>
            </span>
            <span>起</span>
          </div>
        </div>
      </router-link>
    </ul>
    <div><a href="">查看所有产品</a></div>
  </div>
</template>

<script>
export default {
  name: 'HomeFavourite',
  props:['recommendList'],
  data(){
    return {
    }
  },
  filters:{
    clacWidth(score){
      return {
        width:(score / 5 )*100 +'%'
      }
    }
  },
}
</script>

<style scoped>
  .favourite{
    margin-top: .2rem;
    background-color: #fff;
  }
  .favourite h2{
    height: .44rem;
    line-height: .44rem;
    padding: .24rem 0 .26rem;
    font-size: .32rem;
    color: #222;
    text-indent: .4rem;
  }
  .favourite ul{
    margin-left: .2rem;
  }
  .favourite li{
    position: relative;
    padding: .2rem 0;
    border-bottom: 1px solid #eee;
  }
  .favourite li > div{
    float: left;
  }
  .fav-img{
    width: 2rem;
  }
  .fav-img img{
    width: 100%;
  }
  .fav-info{
    position: absolute;
    left: 2rem;
    top: 0;
    bottom: 0;
    right: 0;
    padding-left: .2rem;
  }
  .fav-info h3{
    height: .44rem;
    margin-top: .26rem;
    font-size: .32rem;
    line-height: .44rem;
    color: #222;
  }
  .favourite > div{
    height: .4rem;
    padding: .2rem;
    line-height: .4rem;
    text-align: center;
  }
  .favourite > div a{
    color: #00afc7;
  }
  .mark{
    color: #ff8300;
  }
  .favourite .price{
    height: .46rem;
    margin-top: .22rem;
    font-size: 0;
  }
  .mark-on{
    font-size: .24rem;
  }
  .mark-price{
    font-size: .4rem;
  }
  .price span + span{
    font-size: .24rem;
  }
  .comment{
    font-size: .24rem;
  }
  .scroe{
    margin-top: .12rem;
  }
  .scroe i {
    margin-left: .06rem;
    font-size: .28rem;

  }
  .scroe .start{
    position: relative;
  }
  .scroe .scroe-top{
    overflow: hidden;
    position: absolute;
    left: 0;
    color: #ffb436;
  }
</style>
