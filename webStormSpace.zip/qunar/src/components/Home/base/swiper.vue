<template>
  <div class="swiper">
    <swiper :options="swiperOption" v-if="isShow">
      <!-- slides -->
      <swiper-slide v-for="(item,index) in swiperList" :key="index">
        <a href=""><img class='swiper-img' :src="item.imgUrl"></a>
      </swiper-slide>
      <!-- Optional controls -->
      <div class="swiper-pagination"  slot="pagination"></div>
    </swiper>
  </div>
</template>

<script>
export default {
  name: 'HomeSwiper',
  props:['swiperList'],
  data () {
    return {
      swiperOption: {
        pagination: {
          el: '.swiper-pagination'
        },
        loop:true,
        autoplay:true,
        observeParents:true,
        observer:true
      }
    }
  },
  computed:{
    isShow(){
      return this.swiperList.length>0
    }
  }
}
</script>

<style scoped>
  .swiper >>> .swiper-pagination-bullet-active{
    background-color:#fff;
  }
  .swiper a{
    display: block;
  }
  .swiper-img{
    height: 2rem;
  }
</style>
