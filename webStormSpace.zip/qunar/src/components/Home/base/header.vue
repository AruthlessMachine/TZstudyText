<template>
  <div class="header">
    <div class="header-con">
      <router-link to="/" tag='div' class="last">
          <i class="iconfont icon-fanhui"></i>
      </router-link>
      <div class="search">
        <i class="iconfont icon-sousuo"></i>
        <input type="text" placeholder="输入城市/景点/游玩项目">
      </div>
      <router-link to="/city" tag="div" class="postion">
        <div>
          <span>{{$store.state.city}}</span>
          <i class="iconfont icon-jiantouxiangxia"></i>
        </div>
      </router-link>
    </div>

  </div>
</template>

<script>
export default {
  name: 'HomeHeader',
  data () {
    return {
    }
  }
}
</script>

<style scoped>
  .header{
    width: 100%;
    height: .75rem;
    padding-top: .15rem;
    background: #00bcd4;
  }
  .icon-fanhui{
    font-size: .32rem;
  }
  .header-con{
    height: .6rem;
    line-height: .6rem;
  }
  .header-con > div{
    float: left;
    height: 100%;
  }
  .last,.postion{
    width: 11%;
    text-align: center;
    color:#fff;
  }
  .icon-jiantouxiangxia{
    font-size: .26rem;
  }
  .postion{
    width: 19%;
  }
  .search{
    position: relative;
    width: 70%;
    background: #fff;
    border-radius: .08rem;
  }
  .search input{
    width: 3.6rem;
    height: .6rem;
    margin-left: .3rem;
    text-indent: .4rem;
  }
  .icon-sousuo,.search input{
    vertical-align: top;
  }
  .icon-sousuo{
    position: absolute;
    left: .2rem;
    font-size: .32rem;
    color:#ccc;
  }
</style>
