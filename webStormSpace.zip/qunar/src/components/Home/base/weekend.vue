<template>
  <div class="weekend">
    <h2>周末去哪儿</h2>
    <ul>
      <router-link
        @click.native="changeTitle(item.title)"

        :to="{name:'Week',params:{id:item.id}}"
        tag="li"
        v-for="item in weekendList"
        :key="item.id">
        <div class="week-img">
          <img :src="item.imgUrl" alt="">
        </div>
        <div class="week-title">
          <h4>{{item.title}}</h4>
          <p>{{item.desc}}</p>
        </div>
      </router-link>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'HomeWeekend',
  props:['weekendList'],
  data () {
    return {

    }
  },
  methods:{
    changeTitle(title){
      console.log(title)
      this.$store.commit('changeTitle',title)
    }
  }
}
</script>

<style scoped>
  .weekend h2{
    height: .44rem;
    padding: .24rem 0 .26rem;
    background-color: #f5f5f5;
    line-height: .44rem;
    font-size: .28rem;
    color: #222;
    text-indent: .3rem;
  }
  .week-img{
    height: 2.6rem;
  }
  .week-img img{
    height: 100%;
  }
  .week-title{
    padding: .14rem .2rem .2rem;
  }
  .week-title h4, .week-title p{
    overflow:hidden;
    padding-right: 1.4rem;
    white-space:nowrap;
    text-overflow:ellipsis;
  }
  .week-title h4{
    height: .48rem;
    line-height: .48rem;
    color: #222;
    font-size: .28rem;
  }
  .week-title p{
    height: .42rem;
    line-height: .42rem;
    font-size: .24rem;
  }
</style>
