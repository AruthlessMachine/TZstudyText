<template>
  <div class="nav">
    <swiper :options="swiperOption">
      <!-- slides -->
      <swiper-slide v-for="(data,index) in filterImgs" :key="index">
        <ul>
          <router-link to='' tag="li" v-for="(item,index) in data" :key="index">
            <img :src="item.imgUrl" alt="">
            <p>{{item.desc}}</p>
          </router-link>
        </ul>
      </swiper-slide>
      <!-- Optional controls -->
      <div class="swiper-pagination"  slot="pagination"></div>
    </swiper>
  </div>
</template>

<script>
export default {
  name: 'HomeNav',
  props:['iconList'],
  data () {
    return {
      swiperOption:{
        pagination: {
          el: '.swiper-pagination'
        },
        observeParents:true,
        observer:true
      }
    }
  },
  computed:{
    filterImgs(){
      let data = []

      this.iconList.forEach((v,i)=>{
        let page = ~~(i/8)

        if(!data[page]){
          data[page] = []
        }
        data[page].push(v)
      })
      return data
    }
  }
}
</script>

<style scoped>
  .nav{
    background-color: #fff;
  }
  .nav ul{
    display: flex;
    height: 3.7rem;
    padding-top: .1rem;
    flex-flow:row wrap;
  }
  .nav ul li{
    text-align: center;
    width: 1.7rem;
    height: 1.5rem;
    padding-top: .1rem;
  }
  .nav ul img{
    width: 1.1rem;
  }
  .nav ul p{
    font-size: .28rem;
    margin-top: .08rem;
  }
</style>
