<template>
  <div class="alphabet">
    <ul>
      <li v-for="(city,key) in cities"
          :key="city.id"
      @click="handleClick(key)">{{key}}</li>
    </ul>
  </div>
</template>

<script>
  export default {
    props:['cities'],
    name:'CityAlphabet',
    methods:{
      handleClick(letter){
        this.$store.commit('changeLetter',letter)
      }
    }
  }
</script>

<style scoped>
  .alphabet{
    position:fixed;
    padding-top: 1.8rem;
    text-align: center;
    right:0;
    top:0;
    bottom:0;
    width:.4rem;
  }
  .alphabet li{
    padding-top: .02rem;
    line-height: .4rem;
    color: skyblue;
    font-size: .24rem;
  }

</style>
