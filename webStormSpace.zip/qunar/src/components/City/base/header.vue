<template>
  <div class="header">
    <router-link to="/" tag='div' class="last">
      <i class="iconfont icon-fanhui"></i>
    </router-link>
    <div class="header-title">城市选择</div>
  </div>
</template>

<script>
export default {
  name: 'CityHeader',
  data () {
    return {
    }
  }
}
</script>

<style scoped>
  .header{
    position: relative;
    width: 100%;
    height: .88rem;
    background: #00bcd4;
  }
  .icon-fanhui{
    font-size: .32rem;
  }
  .header > div{
    height: 100%;
    text-align: center;
    line-height: .88rem;
    color:#fff;
  }
  .header-title{
    font-size: .32rem;
  }
  .last{
    position: absolute;
    width: .8rem;
    height: 100%;
  }
</style>
