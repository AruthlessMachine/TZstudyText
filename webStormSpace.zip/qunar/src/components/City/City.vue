<template>
  <div class="city">
    <city-header></city-header>
    <city-search :cities="cities"></city-search>
    <city-list :cities="cities" :hotCities="hotCities"></city-list>
    <city-alphabet :cities="cities"></city-alphabet>
  </div>
</template>

<script>
  import {getCities} from '@/api'

  import CityHeader from './base/header'
  import CitySearch from './base/search'
  import CityList from './base/list'
  import CityAlphabet from './base/alphabet'


  export default {
  name: 'City',
  data () {
    return {
      cities:[],
      hotCities:[],
    }
  },
  components:{
    CityHeader,
    CitySearch,
    CityList,
    CityAlphabet,
  },
  created(){
    this.getData()
  },
  methods:{
    async getData(){
      let {cities,hotCities} = await getCities()
      this.cities = cities
      this.hotCities = hotCities
    }
  }
}
</script>

<style scoped>

</style>
