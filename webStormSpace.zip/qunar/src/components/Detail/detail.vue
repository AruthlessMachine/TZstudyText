<template>
    <div class="detail">
      <detail-header></detail-header>
      <detail-banner
        :bannerImg="bannerImg"
        :gallaryImgs="gallaryImgs"
        :sightName="sightName"
      ></detail-banner>
      <detail-card :cardInfo="cardInfo"></detail-card>
      <detail-recommend :recommendInfo="recommendInfo">
        <h3 class="border-bottom">去哪儿推荐</h3>
      </detail-recommend>
      <detail-calendar :calendarInfo="calendarInfo"></detail-calendar>
      <detail-comment :commentInfo="commentInfo"></detail-comment>
    </div>
</template>

<script>
  import {getDetails} from '@/api'

  import DetailHeader from './base/header'
  import DetailCard from './base/card'
  import DetailRecommend from './base/recommend'
  import DetailBanner from './base/banner'
  import DetailCalendar from './base/calendar'
  import DetailComment from './base/comment'


  export default {
    name:'Detail',
    data() {
      return {
        bannerImg:'',
        cardInfo:{},
        gallaryImgs:[],
        recommendInfo:[],
        sightName:'',
        calendarInfo:[],
        commentInfo:[]
      }
    },
    components:{
      DetailHeader,
      DetailCard,
      DetailRecommend,
      DetailBanner,
      DetailCalendar,
      DetailComment
    },
    created(){
      this.getData()
    },
    methods:{
      async getData(){
        let {bannerImg,cardInfo,gallaryImgs,recommendInfo,sightName,calendarInfo,commentInfo} = await getDetails(this.$route.params.id)
        this.bannerImg = bannerImg
        this.cardInfo = cardInfo
        this.gallaryImgs = gallaryImgs
        this.recommendInfo = recommendInfo
        this.sightName = sightName
        this.calendarInfo = calendarInfo
        this.commentInfo = commentInfo
      }
    }
  }
</script>

<style scoped>
  .detail{
    background-color: #fff;
  }
</style>
