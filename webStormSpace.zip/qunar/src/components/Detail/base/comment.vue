<template>
    <div class="comment">
      <div class="comment-title">
        <h3>用户评论</h3>
      </div>
      <div class="comment-con">
        <div v-for="item in commentInfo">
          <p>{{item.desc}}</p>
          <div class="comment-img">
            <ul class="clearfix" @click="handleClick(item.imgs)">
              <li v-for="(v,i) in item.imgs" v-if="i<6">
                <img :src="v" alt="">
              </li>
            </ul>
            <div>
              <span>共{{item.imgs.length}}张</span>
            </div>
          </div>
        </div>
      </div>
      <div class="comment-all">
        <a href="#">查看全部评论</a>
      </div>

      <common-gallary @close='handleClose' v-show='isShow' :gallaryImgs="commentImg"></common-gallary>
    </div>
</template>

<script>
  import CommonGallary from '@/common/Gallary'

  var CommentGallary;
  export default {
    name:'DetailComment',
    props:['commentInfo'],
    data() {
        return {
          isShow:false,
          commentImg:[]
        }
    },
    components:{
      CommonGallary
    },
    methods:{
      handleClick(img){
        this.commentImg = img
        this.isShow = true
      },
      handleClose(){
        this.isShow = false
      }
    }
  }

</script>

<style scoped>
  .comment{
    /*border-bottom: .2rem solid #f5f5f5;*/
  }

  .comment > div h3{
    position: relative;
    height: .88rem;
    padding: 0 .45rem;
    line-height: .88rem;
    font-size: .3rem;
    color: #333;
  }
  .comment > div h3::before{
    content: '';
    position: absolute;
    left: .2rem;
    top: .3rem;
    height: .3rem;
    width: .1rem;
    background: skyblue;
  }
  .comment-title::before,.comment-con > div::before{
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    border-bottom: 1px solid #ccc;
  }
  .comment > div a{
    display: block;
    text-align: center;
    height: .8rem;
    line-height: .8rem;
    color:inherit;
  }

  .comment-con > div{
    position: relative;
    padding: .1rem .2rem .3rem;
  }

  .comment-con > div p{
    color:#616161;
    font-size: .26rem;
    line-height: .42rem;
  }
  .comment-img{
    position: relative;
    padding: .2rem 0 .1rem;
  }
  .comment-img li{
    overflow: hidden;
    float: left;
    width: 2.05rem;
    height: 1.5rem;
    padding: 0 .07rem;
    margin: .1rem 0;
  }
  .comment-img li img{
    width: 100%;
  }
  .comment-img > div span{
    position: absolute;
    right: 0;
    bottom: .6rem;
    width: 1rem;
    height: .4rem;
    padding-right: .1rem;
    background-color: rgba(0,0,0,.6);
    color: #fff;
    text-align: right;
    line-height: .4rem;
    border-radius: 1rem 0 0 1rem;
  }
</style>
