<template>
    <div class="calendar">
      <ul class='calendar-title border-bottom'>
        <li>
          <p :class='{bot:isShow}' @click="handleTicket">门票</p>
        </li>
        <li>
          <p :class='{bot:!isShow}' @click="handleTourist">一日游</p>
        </li>
      </ul>
      <div  class='calendar-item' v-for='(item,index) in calendarInfo'>
        <h3 class='border-bottom' ref="heaven">{{item.calendarInfo.title}}</h3>
        <div class="calendar-info border-bottom"  @click='handleClick(result)' v-for='result in item.calendarInfo.result' >
          <div class="calendar-left">
            <h4 class="calendar-title">{{result.subtitle}}</h4>
          </div>
          <div class="calendar-right">
            <span>¥{{result.price}}<i class='iconfont icon-jiantouxiangxia' :style="result.styleObj"></i></span>
          </div>
          <detail-recommend v-show='result.isShow' :recommendInfo="result.recommendInfo"></detail-recommend>
        </div>
      </div>
    </div>
</template>

<script>
  import DetailRecommend from '@/components/Detail/base/recommend'
  export default {
    name:'DetailCalendar',
    props:['calendarInfo'],
    components:{
      DetailRecommend
    },
    data(){
      return {
        isShow:true,
      }
    },
    methods:{
      handleClick(result){
        result.isShow = !result.isShow
        result.styleObj.transform = 'rotate('+result.isShow*180+'deg)'
      },
      handleTicket(){
        this.isShow = !this.isShow
        document.documentElement.scrollTop = this.$refs.heaven[0].offsetTop-85
      },
      handleTourist(){
        this.isShow = !this.isShow
        document.documentElement.scrollTop = this.$refs.heaven[2].offsetTop-43
      }
    }
  }
</script>

<style scoped>
  .calendar .recommend>>> .recommend{
    width:100%;
  }
  .calendar .recommend>>> .recommend-title{
    line-height:.4rem;
  }
  .border-bottom::before{
    border-color:#ccc;
  }
  .border-bottom .bot{
    display: inline-block;
    width: 1.6rem;
    border-bottom: .04rem solid skyblue;
  }
  .recommend{
    background-color:#f5f5f5;
  }
  .calendar-item{
    padding:0 .2rem;
    border-bottom:.2rem solid #f5f5f5;
  }

  .calendar-title{
    display:flex;
  }
  .calendar-title li{
    width:50%;
    height:1rem;
    line-height:1rem;
    text-align:center;
    font-size:.3rem;
  }

  .calendar-item h3{
    height: 1rem;
    line-height:1rem;
    font-size:.32rem;
    color: #333;
  }

  .calendar-info{
    display:flex;
    flex-wrap: wrap;
    justify-content:space-between;
    padding: .1rem 0;
  }

  .calendar-left{
    position: relative;
    width:100%;
    color:#616161;
  }

  .calendar-left  h4{
    display: -webkit-box;
    overflow:hidden;
    width: 80%;
    line-height:.6rem;
    font-size:.28rem;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  }

  .calendar-left p{
    line-height:.5rem;
    font-size:.28rem;
  }

  .calendar-left span{
    color:#00afc7;
    font-size:.24rem;
  }

  .calendar-right{
    position: absolute;
    right: .46rem;
    top: .2rem;
    display:flex;
    text-align:center;
  }

  .calendar-right span{
    color:#ff9852;
    font-size:.35rem;
    font-weight:400;
  }
  .calendar-right span::first-letter{
    font-size:.24rem;
  }
  .calendar-right span i{
    position:absolute;
    font-size:.24rem;
    color:#bbb;
  }
</style>
