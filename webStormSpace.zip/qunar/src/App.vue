<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App',
  created(){
    let html = document.querySelector('html');
    let width
    changeRem();
    //添加resize事件
    window.addEventListener('resize',changeRem);
    function changeRem() {
      //获取设备宽度
      width = html.getBoundingClientRect().width;
      html.style.fontSize = width/7+ 'px';
    }
  }
}
</script>

<style>
  *{
    margin: 0;
    padding: 0;
  }
  ul,li{
    list-style: none;
  }
  img{
    border: 0;
  }
  body{
    height: 100%;
    background-color: #efefef;
    font-size: .28rem;
    color: #666;
  }
  .clearfix:after{
    display: block;
    content: '';
    clear: both;
  }
  .clearfix{
    zoom: 1;
  }
</style>
