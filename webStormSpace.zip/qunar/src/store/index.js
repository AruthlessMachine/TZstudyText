import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)

export default new Vuex.Store({
  state:{
    letter:'',
    city:localStorage.getItem('city1')||'南京',
    title:''||'周末去哪儿'
  },
  mutations:{
    changeLetter(state,letter){
      state.letter = letter
    },
    changeCity(state,city){
      state.city = city
      localStorage.setItem('city1',city)
    },
    changeTitle(state,title){
      state.title = title
    }
  }
})
