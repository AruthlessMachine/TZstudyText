import  axios from 'axios'

axios.interceptors.response.use(function (response) {
  return response.data.data;
});


//请求home组件的数据接口
export let getHome = ()=>{
  return axios.post('http://wxxbg.cn:3007/home').then((res)=>{
    return res
  })
}

//请求city组件的数据接口
export let getCities = ()=>{
  return axios.post('http://wxxbg.cn:3007/city').then((res)=>{
    return res
  })
}

export let getDetails = (id)=>{
  return axios.post('http://wxxbg.cn:3007/detail',{id}).then((res)=>{
    return res
  })
}

export let getWeek = (id)=>{
  return axios.post('http://wxxbg.cn:3007/week',{id}).then((res)=>{
    return res
  })
}

