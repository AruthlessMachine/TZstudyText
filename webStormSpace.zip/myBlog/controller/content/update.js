const Content = require('../../schema/content')

exports.showUpdate = function(req,res){
    let id = req.query.id
    Content.findById(id).populate('category').then((result)=>{
        res.render('admin/content/update',{
            userInfo:req.userInfo,
            result
        })
    })
}

exports.update = function(req,res){
    let id = req.query.id
    let {title,description,content} = req.body
    let optionMessage = {
        location:'内容首页',
        option:'内容修改',
        message:'内容标题不能为空'
    }
    if(title ==='') {
        res.render('admin/error',{
            userInfo:req.userInfo,
            optionMessage
        })
        return
    }
    if(description ==='') {
        optionMessage.message = '内容简介不能为空'
        res.render('admin/error',{
            userInfo:req.userInfo,
            optionMessage
        })
        return
    }
    if(content ==='') {
        optionMessage.message = '内容正文不能为空'
        res.render('admin/error',{
            userInfo:req.userInfo,
            optionMessage
        })
        return
    }

    Content.updateOne({_id:id},{$set:{title,description,content,time:new Date}}).then((result)=>{
        optionMessage.message = '修改内容成功!'
        optionMessage.href = '返回内容首页'
        res.render('admin/success',{
            userInfo:req.userInfo,
            optionMessage,
            url:'/admin/content'
        })
    })
}