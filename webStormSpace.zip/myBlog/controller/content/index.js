const Content = require('../../schema/content')

exports.showIndex = function(req,res) {
    let page = +req.query.page || 1
    let limit = 10

    Content.count().then((count)=>{
        let pageMax = Math.ceil(count/limit)
        page = Math.min(page,pageMax) || Math.max(page,0)
        let skip = (page-1)*limit
        if(!count) {
            res.render('admin/content/index',{
                userInfo:req.userInfo,
                results:[],
                page,
                pageMax
            })
            return
        }
        Content.find().limit(limit).skip(skip).sort({_id:-1}).populate('category').then((results)=>{
            res.render('admin/content/index',{
                userInfo:req.userInfo,
                results,
                page,
                pageMax
            })
        })
    })
}