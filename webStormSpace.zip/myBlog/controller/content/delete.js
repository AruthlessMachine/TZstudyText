const Content = require('../../schema/content')

exports.showDelete = function (req,res) {
    let id = req.query.id
    Content.findById(id).populate('category').then((result)=>{
        res.render('admin/content/delete',{
            userInfo:req.userInfo,
            result
        })
    })
}

exports.delete = function (req,res) {
    let title = req.body.title
    let optionMessage = {
        location:'内容首页',
        option:'内容删除',
        message:'删除内容标题不能为空'
    }
    if(title ==='') {
        res.render('admin/error',{
            userInfo:req.userInfo,
            optionMessage
        })
        return
    }

    Content.deleteOne({title}).then((result)=>{
        if(!result.deletedCount){
            optionMessage.message = '删除内容标题不存在'
            res.render('admin/error',{
                userInfo:req.userInfo,
                optionMessage
            })
            return
        }

        optionMessage.message = '删除内容成功!'
        optionMessage.href = '返回内容首页'
        res.render('admin/success',{
            userInfo:req.userInfo,
            optionMessage,
            url:'/admin/content'
        })
    })

}