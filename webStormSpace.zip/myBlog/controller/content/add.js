const Content = require('../../schema/content')
const Category = require('../../schema/category')

exports.showAdd = function(req,res){
    Category.find().then((results)=>{
        res.render('admin/content/add',{
            userInfo:req.userInfo,
            results
        })
    })
}

exports.add = function(req,res){
    let optionMessage = {
        location:'内容首页',
        option:'内容添加',
        message:'分类名称不存在'
    }
    let {category,title,description,content} = req.body

    if(category==='') {
        res.render('admin/error',{
            userInfo:req.userInfo,
            optionMessage
        })
        return
    }

    if(title==='') {
        optionMessage.message = '内容标题不能为空'
        res.render('admin/error',{
            userInfo:req.userInfo,
            optionMessage
        })
        return
    }

    if(description==='') {
        optionMessage.message = '内容简介不能为空'
        res.render('admin/error',{
            userInfo:req.userInfo,
            optionMessage
        })
        return
    }

    if(content==='') {
        optionMessage.message = '内容正文不能为空'
        res.render('admin/error',{
            userInfo:req.userInfo,
            optionMessage
        })
        return
    }

    Content.findOne({title}).then((results)=>{
        if(results){
            optionMessage.message = '该标题已存在'
            res.render('admin/error',{
                userInfo:req.userInfo,
                optionMessage
            })
        }else{
            new Content({
                category,
                title,
                description,
                content,
                author:req.userInfo.username
            }).save().then(()=>{
                optionMessage.message = '保存成功'
                optionMessage.href = '返回内容首页'
                res.render('admin/success',{
                    userInfo:req.userInfo,
                    optionMessage,
                    url:'/admin/content'
                })
            })
        }
    })
}