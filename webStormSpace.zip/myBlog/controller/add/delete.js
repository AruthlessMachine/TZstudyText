const Category = require('../../schema/category')

exports.delete = function (req,res) {

}