const express = require('express')
const User = require('../schema/users')

const addCategory = require('../controller/category/add')
const indexCategory = require('../controller/category/index')
const updateCategory = require('../controller/category/update')
const deleteCategory = require('../controller/add/delete')

const addContent = require('../controller/content/add')
const indexContent = require('../controller/content/index')
const updateContent = require('../controller/content/update')
const deleteContent = require('../controller/content/delete')

const router = express.Router()

router.use((req,res,next)=>{
    if(!req.userInfo.isAdmin){
        res.send('你不是管理员')
        return
    }
    next()
})

router.get('/',(req,res)=>{
    res.render('admin/index',{
        userInfo:req.userInfo
    })
})

router.get('/user',(req,res)=>{
    let page = +req.query.page || 1
    let limit = 5

    User.count().then((count)=>{
        let pageMax = Math.ceil(count/limit)
        page = Math.min(page,pageMax)
        let skip = (page-1)*limit

        User.find().limit(limit).skip(skip).sort({_id:-1}).then((results)=>{
            res.render('admin/user/index',{
                userInfo:req.userInfo,
                results,
                page,
                pageMax
            })
        })
    })
})

router.get('/category',indexCategory.showIndex)

router.get('/category/add',addCategory.showAdd)

router.post('/category/add',addCategory.add)

router.get('/category/update',updateCategory.showUpdate)

router.post('/category/update',updateCategory.update)

router.get('/category/delete',deleteCategory.showDelete)

router.post('/category/delete',deleteCategory.delete)



router.get('/content',indexContent.showIndex)

router.get('/content/add',addContent.showAdd)

router.post('/content/add',addContent.add)

router.get('/content/update',updateContent.showUpdate)

router.post('/content/update',updateContent.update)

router.get('/content/delete',deleteContent.showDelete)

router.post('/content/delete',deleteContent.delete)


module.exports = router