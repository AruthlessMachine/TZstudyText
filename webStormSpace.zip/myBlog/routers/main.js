const express = require('express')
const Category = require('../schema/category')
const Content = require('../schema/content')

const router = express.Router()
let data={}

router.use((req,res,next)=>{
    data.userInfo = req.userInfo
    Category.find().then((categorys)=>{
        data.categorys = categorys
        next()
    })
})

router.get('/',(req,res)=>{
    data.page = +req.query.page || 1
    data.limit = 4
    data.category = req.query.category

    let where = {}
    if(data.category){
        where.category = data.category
    }

    Content.find(where).count().then((count)=>{
        data.pageMax = Math.ceil(count/data.limit)
        data.page = Math.min(data.page,data.pageMax) || Math.max(data.page,0)
        data.skip = (data.page-1)*data.limit
        return Content.find(where).limit(data.limit).skip(data.skip).sort({_id:-1}).populate('category')
    }).then((contents)=>{
        data.contents = contents
        res.render('main/index',data)
    })
})

router.get('/view',(req,res)=>{
    let contentId = req.query.contentId;

    Content.findOne({_id:contentId}).populate('category').then((content)=>{
        content.views++
        content.save()
        data.content = content
        res.render('main/view',data)
    })
})

router.post('/comment',(req,res)=>{

    if(!req.userInfo){
        data.code = 1;
        data.message = '你还没有登录,请先登录';
        res.send(data);
        return;
    }

    let {contentId,comment} = req.body;


    //定义评论的格式
    let commentData = {
        comment,
        time:new Date,
        username:req.userInfo.username
    }
    Content.findById(contentId).then((result)=>{
        //添加新的评论
        result.comment.push(commentData);
        //保存这篇文章
        result.save().then(()=>{
            res.send(result.comment)
        });
    })


})


router.get('/comment',(req,res)=>{

    let contentId = req.query.contentId;
    Content.findById(contentId).then((result)=>{
        res.send(result.comment)

    })
})

module.exports = router