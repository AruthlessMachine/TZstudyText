const express = require('express')
const User = require('../schema/users')

const router = express.Router()

let responseDate = {}
router.post('/register',(req,res)=>{
    let {username,password,repassword} = req.body
    if(username === ''){
        responseDate.code = 1
        responseDate.message = '用户名不能为空'
        res.send(responseDate)
        return
    }

    if(password === ''){
        responseDate.code = 2
        responseDate.message = '密码不能为空'
        res.send(responseDate)
        return
    }

    if(repassword === ''){
        responseDate.code = 3
        responseDate.message = '密码不能为空'
        res.send(responseDate)
        return
    }

    User.findOne({username}).then((somebody)=>{
        if(somebody){
            console.log(1)

            responseDate.code = 4
            responseDate.message = '该用户已被注册'
            res.send(responseDate)
            return
        }

        new User({
            username,
            password
        }).save().then(()=>{
            responseDate.code = 0
            responseDate.message = '注册成功'
            res.send(responseDate)
        })
    })

})

router.post('/login',(req,res)=>{
    let {username,password} = req.body

    if(username === ''){
        responseDate.code = 1
        responseDate.message = '用户名不能为空'
        res.send(responseDate)
        return
    }

    if(password === ''){
        responseDate.code = 2
        responseDate.message = '密码不能为空'
        res.send(responseDate)
        return
    }

    User.findOne({username,password}).then((somebody)=>{
        if(!somebody){
            responseDate.code = 3

            responseDate.message = '用户名不纯在或密码错误'
            res.send(responseDate)

            return
        }

        responseDate.code = 0
        responseDate.message = '登录成功'
        responseDate.userInfo = {
            id:somebody._id,
            username:somebody.username,
            isAdmin:somebody.isAdmin
        }
        res.cookie('userInfo',JSON.stringify(responseDate.userInfo),{
            maxAge:999999999
        })

        res.send(responseDate)
    })
})

router.get('/loginout',(req,res)=>{
    res.cookie('userInfo','')
    res.send()
})

module.exports = router