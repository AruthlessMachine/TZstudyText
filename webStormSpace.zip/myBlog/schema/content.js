const mongoose = require('mongoose')

const contentSchema = new mongoose.Schema({
    category:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'categorys'
    },
    title:String,
    description:String,
    content:String,

    // 作者
    author:String,
    //阅读量
    views:{
        type:Number,
        default: 0
    },
    comment:{
        type:Array,
        default:[]
    },
    time:{
        type:Date,
        default:new Date()
    }
})

module.exports = mongoose.model('contents',contentSchema)