const express = require('express')
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const cookieParser = require('cookie-parser')
const app = express()

//使用body-parser 中间件解析post数据
app.use(bodyParser.urlencoded({
    extended:false,
}))

app.use(cookieParser())
app.set('view engine','ejs')
app.use(express.static('public'))

app.use((req,res,next)=>{
    if(req.cookies.userInfo){
        req.userInfo = JSON.parse(req.cookies.userInfo)
    }
    next()
})

app.use('/admin',require('./routers/admin'))
app.use('/api',require('./routers/api'))
app.use('/',require('./routers/main'))



mongoose.connect('mongodb://localhost:27017/blog',{useNewUrlParser:true},(err)=>{
    if(err){
        console.log('数据库未连接')
        return
    } else {
        console.log('数据库已连接')
    }

    app.listen(80)
})