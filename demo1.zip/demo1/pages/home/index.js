// pages/home/index.js
import {
    getMultiData,
    getNextData
} from '../../cervice/api.js'

const ARR = ['pop', 'sell', 'new']

Page({
    data: {
        banner: {},
        recommend: {},
        page: 1,
        type: 'pop',
        goods: {
            'pop': {
                page:0,
                list:[]
            },
            'sell': {
                page:0,
                list: []
            },
            'new': {
                page:0,
                list: []
            }
        },
        height:0,
        isShow:false
    },

    async onLoad(options) {
        let {
            banner,
            recommend
        } = await getMultiData()
        this.setData({
            banner,
            recommend
        })

        this._getNextList('pop')
        this._getNextList('sell')
        this._getNextList('new')
    },


    async _getNextList(type) {
        let page = this.data.goods[type].page + 1
        let newListKey = `goods.${type}.list`
        let newPageKey = `goods.${type}.page`

        let {list} = await getNextData({
            type,
            page
        })
        let newList = this.data.goods[type].list
        newList.push(...list)
        this.setData({
            [newListKey]: newList,
            [newPageKey]: page
        })

        wx.hideLoading()
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {
        this._getNextList(this.data.type)
        wx.showLoading({
            title: '加载中...',
            mask:true
        })
    },

    onShow(){
        this._getScrollOffset()
    },

    onPageScroll({scrollTop}){
        let height = this.data.height + 300
        if ( scrollTop > height ){
            this.setData({
                isShow:true
            })
        } else {
            this.setData({
                isShow: false
            })
        }
    },

    _getScrollOffset() {
        wx.createSelectorQuery().select('#tolist').boundingClientRect((res)=>{
            this.setData({
                height:res.top
            })
        }).exec()
    },

    // 事件处理
    handleTabClick(event) {
        let index = event.detail.index
        this.setData({
            type: ARR[index]
        })
        wx.showToast({
            title: '加载中...',
            mask:true,
            duration:300,
            icon:'loading'
        })

        wx.pageScrollTo({
            selector:'#tolist',
            duration:0
        })
    }
})