// pages/home/childCom/w-option/index.js
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        isShow:{
            type:Boolean,
            value:false
        }
    },

 
    data: {
        currentIndex:0
    },

    methods: {
        handleClick(event) {
            let newIndex = event.currentTarget.dataset.index
            if ( this.data.currentIndex == newIndex ) return
            this.setData({
                currentIndex: newIndex
            })
            this.triggerEvent('tabClick', { index: newIndex} )
        }
    }
    
})
