// pages/home/childCom/w-fash/index.js
Component({
    /**
     * 组件的属性列表
     */
    properties: {

    }
})
