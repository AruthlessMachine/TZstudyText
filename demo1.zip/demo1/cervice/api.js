import req from './network.js'


export let getMultiData = async function(data){
    return await req.get('/home/multidata')
}

export let getNextData = async function (data) {
    return await req.get('/home/data',data)
}
