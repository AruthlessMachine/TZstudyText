
export default new (class {
    constructor(){
        this.type = 'GET'
        this.url = ''
        this.data = {}
    }

    request(){
        return new Promise((resolve, reject)=>{
            wx.request({
                url: 'http://123.207.32.32:8000' + this.url,
                data: this.data,
                header: {},
                method: this.type,
                dataType: 'json',
                responseType: 'text',
                success(res){
                    resolve(res.data.data)
                },
                fail: reject,
                complete: function (res) { },
            })
        })
        
    }
    get(url, data){
        this.url = url
        this.type = 'GET'
        this.data = data

        return this.request(data).then((data) => {
            return data
        }).catch((res) => {
            return res
        })
    }
    post(url, data){
        this.url = url
        this.type = 'POST'
        this.data = data

        return this.request().then((data)=>{
            return data
        }).catch((res)=>{
            return res
        })
    }
})()


