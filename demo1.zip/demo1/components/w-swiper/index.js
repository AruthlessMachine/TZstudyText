// components/w-swiper/index.js
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        list:{
            type:Array,
            value:[]
        }
    },
})
