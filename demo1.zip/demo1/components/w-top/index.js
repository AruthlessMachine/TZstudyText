// components/w-top/index.js
Component({
    methods: {
        handleGoToTop(){
            wx.pageScrollTo({
                scrollTop:0
            })
        }
    }
})
