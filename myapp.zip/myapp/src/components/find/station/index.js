import React, {Component} from 'react';
import {
    StyleSheet,
    View,
    Image,
    Text
} from 'react-native';

export default class  extends Component {
    render() {
        return (
            <View>
                <Text>这里是电台</Text>
            </View>
        )
    }
}

let s = StyleSheet.create({

})