import React, {Component} from 'react';
import {
    StyleSheet,
    View,
    Image,
    Text
} from 'react-native';

import Swiper from '../../common/swiper'

export default class  extends Component {
    render() {
        return (
            <View>
                <Swiper></Swiper>
            </View>
        )
    }
}

let s = StyleSheet.create({

})