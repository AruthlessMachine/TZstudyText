
import {
    createAppContainer
} from 'react-navigation'

import {
    tabNav
} from './src/nav/index'

export default createAppContainer( tabNav )